package com.ayman.badgepro

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FoundDevice(val name: String, val address: String, val rssi: Int, val device: BluetoothDevice)

enum class LinkState { IDLE, SCANNING, CONNECTING, CONNECTED }

@SuppressLint("MissingPermission")
class BadgeBle(context: Context) {

    private val ctx = context.applicationContext
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val main = Handler(Looper.getMainLooper())

    val devices = mutableStateListOf<FoundDevice>()
    val log = mutableStateListOf<String>()
    var state by mutableStateOf(LinkState.IDLE)
        private set
    var connectedName by mutableStateOf("")
        private set
    var services by mutableStateOf(listOf<String>())
        private set
    var mtu by mutableStateOf(23)
        private set
    var lastInfo by mutableStateOf("")
        private set

    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private val queue = ArrayDeque<ByteArray>()
    private var writing = false
    private var gap = 40L

    val isBluetoothOn: Boolean get() = adapter?.isEnabled == true

    // ---------- Logging ----------
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    fun addLog(msg: String) {
        val line = "${fmt.format(Date())}  $msg"
        main.post {
            log.add(0, line)
            while (log.size > 400) log.removeAt(log.lastIndex)
        }
    }
    fun logText(): String = log.reversed().joinToString("\n")

    // ---------- Scan ----------
    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val name = result.scanRecord?.deviceName ?: d.name ?: return
            main.post {
                val idx = devices.indexOfFirst { it.address == d.address }
                val item = FoundDevice(name, d.address, result.rssi, d)
                if (idx >= 0) devices[idx] = item else devices.add(item)
                val sorted = devices.sortedWith(
                    compareByDescending<FoundDevice> { it.name.startsWith("Z0") }.thenByDescending { it.rssi }
                )
                devices.clear(); devices.addAll(sorted)
            }
        }
        override fun onScanFailed(errorCode: Int) {
            addLog("Scan failed: $errorCode")
            main.post { state = LinkState.IDLE }
        }
    }

    fun startScan() {
        val scanner = adapter?.bluetoothLeScanner ?: run { addLog("Bluetooth is off"); return }
        devices.clear()
        state = LinkState.SCANNING
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(null, settings, scanCb)
        addLog("Scanning...")
        main.postDelayed({ stopScan() }, 12_000)
    }

    fun stopScan() {
        try { adapter?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {}
        if (state == LinkState.SCANNING) state = LinkState.IDLE
    }

    // ---------- Connect ----------
    fun connect(d: FoundDevice) = connectDevice(d.device, d.name)

    /** Opens our own GATT client for the direct DF97 channel (text, etc.). */
    fun connectDevice(device: BluetoothDevice, name: String) {
        stopScan()
        if (gatt != null) return
        state = LinkState.CONNECTING
        connectedName = name
        addLog("Direct channel: connecting to $name (${device.address})")
        gatt = device.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    fun markConnecting(name: String) {
        stopScan()
        connectedName = name
        state = LinkState.CONNECTING
    }

    fun disconnect() {
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        writeChar = null
        queue.clear()
        writing = false
        state = LinkState.IDLE
        services = emptyList()
        addLog("Disconnected")
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                addLog("Connected, requesting MTU 512")
                main.postDelayed({ g.requestMtu(512) }, 300)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                addLog("Link lost (status $status)")
                g.close()
                main.post {
                    gatt = null; writeChar = null; queue.clear(); writing = false
                    state = LinkState.IDLE; services = emptyList()
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, newMtu: Int, status: Int) {
            main.post { mtu = newMtu }
            addLog("MTU = $newMtu")
            g.discoverServices()
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val list = g.services.map { s ->
                val chars = s.characteristics.joinToString { c -> shortUuid(c.uuid.toString()) }
                "${shortUuid(s.uuid.toString())}  [$chars]"
            }
            main.post { services = list }
            addLog("Services: ${g.services.joinToString { shortUuid(it.uuid.toString()) }}")

            val svc = g.getService(Protocol.SERVICE)
            if (svc == null) {
                addLog("DF97 service not found. This may not be a Z01 badge.")
                main.post { state = LinkState.CONNECTED }
                return
            }
            writeChar = svc.getCharacteristic(Protocol.WRITE)
            val notify = svc.getCharacteristic(Protocol.NOTIFY)
            if (notify != null) {
                g.setCharacteristicNotification(notify, true)
                val desc = notify.getDescriptor(Protocol.CCCD)
                if (desc != null) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        g.writeDescriptor(desc, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                    } else {
                        @Suppress("DEPRECATION")
                        desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        @Suppress("DEPRECATION")
                        g.writeDescriptor(desc)
                    }
                }
            }
            addLog("Ready. Write=${writeChar != null}, Notify=${notify != null}")
            main.post { state = LinkState.CONNECTED }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) addLog("Write failed (status $status)")
            main.postDelayed({ writing = false; pump() }, gap)
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT < 33) {
                @Suppress("DEPRECATION")
                onRx(c.value ?: return)
            }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            onRx(value)
        }
    }

    private fun onRx(v: ByteArray) {
        val d = Protocol.describe(v)
        addLog("RX  ${Protocol.hex(v)}" + if (d.isNotEmpty()) "   → $d" else "")
        if (d.isNotEmpty()) main.post { lastInfo = d }
    }

    // ---------- Write queue ----------
    fun send(vararg frames: ByteArray, gapMs: Long = 40) {
        if (writeChar == null) { addLog("Not ready to send"); return }
        gap = gapMs
        frames.forEach { queue.addLast(it) }
        pump()
    }

    private fun pump() {
        if (writing) return
        val g = gatt ?: return
        val c = writeChar ?: return
        val next = queue.removeFirstOrNull() ?: return
        writing = true
        val noResp = (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0 &&
            (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) == 0
        val type = if (noResp) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        addLog("TX  ${Protocol.hex(next)}")
        val ok = if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, next, type) == BluetoothGatt.GATT_SUCCESS
        } else {
            @Suppress("DEPRECATION")
            c.writeType = type
            @Suppress("DEPRECATION")
            c.value = next
            @Suppress("DEPRECATION")
            g.writeCharacteristic(c)
        }
        if (!ok) addLog("Write rejected by Android")
        // No-response writes (or rejected writes) get no callback, so move on by timer.
        if (noResp || !ok) main.postDelayed({ writing = false; pump() }, gap)
    }

    fun sendText(text: String) {
        val maxPayload = (mtu - 3 - 10).coerceIn(10, 230)
        val frames = Protocol.textFrames(text, maxPayload)
        addLog("Sending text in ${frames.size} frame(s)")
        send(*frames.toTypedArray(), gapMs = 150)
    }

    private fun shortUuid(u: String): String =
        if (u.endsWith("-0000-1000-8000-00805f9b34fb")) u.substring(4, 8).uppercase() else u.uppercase()
}
