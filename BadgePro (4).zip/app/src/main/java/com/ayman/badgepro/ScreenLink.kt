package com.ayman.badgepro

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jieli.bluetooth.bean.base.BaseError
import com.jieli.bluetooth.bean.charging_case.ChargingCaseInfo
import com.jieli.bluetooth.bean.file.op.CreateFileParam
import com.jieli.bluetooth.bean.message.MessageInfo
import com.jieli.bluetooth.bean.settings.v0.ResourceInfo
import com.jieli.bluetooth.bean.settings.v0.SDKMessage
import com.jieli.bluetooth.bean.settings.v0.ScreenInfo
import com.jieli.bluetooth.bean.settings.v0.SettingFunction
import com.jieli.bluetooth.impl.rcsp.RCSPController
import com.jieli.bluetooth.impl.rcsp.charging_case.ChargingCaseOpImpl
import com.jieli.bluetooth.interfaces.rcsp.callback.OnRcspActionCallback
import com.jieli.bluetooth.interfaces.rcsp.callback.OnTaskStateListener
import com.jieli.bluetooth.interfaces.rcsp.charging_case.OnChargingCaseListener
import com.jieli.bmp_convert.BmpConvert
import com.jieli.filebrowse.bean.RegFile
import com.jieli.filebrowse.bean.SDCardBean
import com.jieli.lib.gif.GifConverter
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * The Z01 runs JieLi's "colour screen" firmware. This class uses the official
 * ChargingCase API, the same one BagiBagi uses for wallpapers.
 */
@SuppressLint("MissingPermission")
class ScreenLink(context: Context, private val log: (String) -> Unit) {

    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val rc = RCSPController.getInstance()
    private val op: ChargingCaseOpImpl = ChargingCaseOpImpl.instance(rc.rcspOp)
    private val bmp = BmpConvert()

    var screenW by mutableStateOf(0); private set
    var screenH by mutableStateOf(0); private set
    var circular by mutableStateOf(true); private set
    var chip by mutableStateOf(-1); private set
    var brightness by mutableStateOf(-1); private set
    var uploading by mutableStateOf(false); private set
    var progress by mutableStateOf(0); private set
    var uploadStatus by mutableStateOf(""); private set
    val savers = mutableStateListOf<RegFile>()

    private val listener = object : OnChargingCaseListener {
        override fun onInit(device: BluetoothDevice?, state: Int) {
            log("Screen init state = $state ${if (state == 0) "(OK)" else "(error)"}")
            if (state == 0) main.postDelayed({ readAll() }, 300)
        }

        override fun onChargingCaseInfoChange(device: BluetoothDevice?, func: Int, info: ChargingCaseInfo?) {
            if (info == null) return
            when (func) {
                ChargingCaseInfo.FUNC_BRIGHTNESS -> main.post { brightness = info.brightness }
                ChargingCaseInfo.FUNC_CURRENT_SCREEN_SAVER -> log("Current screen saver: ${info.currentScreenSaver}")
            }
        }

        override fun onChargingCaseEvent(device: BluetoothDevice?, function: SettingFunction?) {}
    }

    init {
        op.addOnChargingCaseListener(listener)
    }

    private val device: BluetoothDevice? get() = rc.usingDevice

    private fun <T> cb(label: String, ok: (T?) -> Unit = {}) = object : OnRcspActionCallback<T> {
        override fun onSuccess(d: BluetoothDevice?, result: T) {
            log("✓ $label: ${result ?: "ok"}")
            main.post { ok(result) }
        }

        override fun onError(d: BluetoothDevice?, e: BaseError?) {
            log("✗ $label: code=${e?.code} sub=${e?.subCode} ${e?.message ?: ""}")
        }
    }

    fun readAll() {
        readSdk(); readScreen(); readBrightness()
    }

    fun readSdk() {
        val d = device ?: return
        op.readSDKMessage(d, cb<SDKMessage>("SDK info") { m -> if (m != null) chip = m.chip })
    }

    fun readScreen() {
        val d = device ?: return
        op.readScreenInfo(d, cb<ScreenInfo>("Screen info") { s ->
            if (s != null) { screenW = s.width; screenH = s.height; circular = s.isCircular }
        })
    }

    fun readBrightness() {
        val d = device ?: return
        op.getBrightness(d, cb<Int>("Brightness") { b -> if (b != null) brightness = b })
    }

    fun changeBrightness(value: Int) {
        val d = device ?: return
        op.setBrightness(d, value.coerceIn(0, 100), cb<Boolean>("Set brightness $value") { brightness = value })
    }

    fun setFlashlight(on: Boolean) {
        val d = device ?: return
        op.setFlashlightState(d, on, cb<Boolean>("Flashlight $on"))
    }

    fun currentSaver() {
        val d = device ?: return
        op.getCurrentScreenSaver(d, cb<ResourceInfo>("Current screen saver"))
    }

    private fun flash(): SDCardBean? {
        val d = device ?: return null
        val list = op.getOnlineStorages(d).orEmpty().ifEmpty { op.fileOp.onlineStorage.orEmpty() }
        log("Storages: " + list.joinToString { "${it.name}(flash=${it.isFlash},online=${it.isOnline})" })
        return list.firstOrNull { it.isFlash && it.isOnline } ?: list.firstOrNull()
    }

    fun browseSavers() {
        val d = device ?: return
        val s = flash() ?: run { log("✗ No storage found on badge"); return }
        op.browseScreenSavers(d, s.devHandler, cb<List<RegFile>>("Screen savers list") { list ->
            savers.clear(); if (list != null) savers.addAll(list)
        })
    }

    fun useSaver(f: RegFile) {
        val d = device ?: return
        val s = flash() ?: return
        op.setCurrentScreenSaver(d, s.devHandler, f.path, cb<Boolean>("Use ${f.path}"))
    }

    fun pushMessage(title: String, content: String) {
        val d = device ?: return
        val msg = MessageInfo("com.ayman.badgepro", MessageInfo.FLAG_DEFAULT, title, content, System.currentTimeMillis())
        op.pushMessageInfo(d, msg, cb<Boolean>("Push message"))
    }

    // ---------------- Photo upload ----------------

    fun uploadImage(uri: Uri) {
        if (uploading) { log("Upload already running"); return }
        val d = device ?: run { log("✗ Not connected"); return }
        uploading = true; progress = 0; uploadStatus = "تجهيز الصورة..."
        worker.execute {
            try {
                val w = if (screenW > 0) screenW else 240
                val h = if (screenH > 0) screenH else 240
                val dir = File(ctx.cacheDir, "upload").apply { deleteRecursively(); mkdirs() }
                val mime = ctx.contentResolver.getType(uri) ?: ""
                val name = "VIE_" + java.lang.Long.toString(System.currentTimeMillis() % 1_679_616, 36).uppercase().padStart(4, '0')
                val out = File(dir, name)
                val bytes: ByteArray

                if (mime.contains("gif")) {
                    val src = File(dir, "src.gif")
                    ctx.contentResolver.openInputStream(uri)!!.use { i -> src.outputStream().use { i.copyTo(it) } }
                    val gifChip = if (chip == SDKMessage.CHIP_701N) GifConverter.CHIP_701N else GifConverter.CHIP_707N
                    val r = GifConverter.getInstance().gif2Bin(src.path, GifConverter.MODE_LOW_COMPRESSION_RATE, gifChip)
                    if (!r.isSuccess) throw IllegalStateException("GIF convert failed: ${r.code} ${r.message}")
                    bytes = r.gifBin.data
                    out.writeBytes(bytes)
                } else {
                    val bmpIn = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) }
                        ?: throw IllegalStateException("Can't read image")
                    val fitted = cropFill(bmpIn, w, h)
                    val src = File(dir, "src.png")
                    FileOutputStream(src).use { fitted.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    val type = if (chip == SDKMessage.CHIP_701N) BmpConvert.TYPE_701N_RGB else BmpConvert.TYPE_707N_RGB
                    val ret = bmp.bitmapConvertBlock(type, src.path, out.path)
                    log("Image ${w}x$h converted (type $type) → $ret bytes")
                    if (ret <= 0 || !out.exists()) throw IllegalStateException("Image convert failed ($ret)")
                    bytes = out.readBytes()
                }
                log("Prepared ${out.name}, ${bytes.size} bytes")
                main.post { transfer(d, out) }
            } catch (e: Exception) {
                log("✗ Prepare failed: ${e.message}")
                main.post { uploading = false; uploadStatus = "فشل التجهيز: ${e.message}" }
            }
        }
    }

    private fun transfer(d: BluetoothDevice, file: File) {
        val storage = flash() ?: run {
            log("✗ No flash storage"); uploading = false; uploadStatus = "ما لقيت ذاكرة بالبادج"; return
        }
        uploadStatus = "جاري الإرسال..."
        op.fileOp.createBigFile(CreateFileParam(d, file, storage), object : OnTaskStateListener {
            override fun onStart() { log("Transfer started") }
            override fun onProgress(p: Int) { main.post { progress = p } }
            override fun onStop() {
                log("Transfer done, applying as screen saver")
                main.post { uploadStatus = "تطبيق الصورة..." }
                apply(d, storage, file.name, withSlash = true)
            }
            override fun onCancel(reason: Int) {
                log("Transfer cancelled ($reason)")
                main.post { uploading = false; uploadStatus = "انلغى" }
            }
            override fun onError(code: Int, message: String?) {
                log("✗ Transfer error $code $message")
                main.post { uploading = false; uploadStatus = "خطأ بالإرسال ($code)" }
            }
        })
    }

    private fun apply(d: BluetoothDevice, storage: SDCardBean, name: String, withSlash: Boolean) {
        val path = if (withSlash) "/$name" else name
        op.setCurrentScreenSaver(d, storage.devHandler, path, object : OnRcspActionCallback<Boolean> {
            override fun onSuccess(dev: BluetoothDevice?, ok: Boolean?) {
                log("✓ Screen saver set: $path")
                main.post { uploading = false; progress = 100; uploadStatus = "✅ تمت!" }
            }
            override fun onError(dev: BluetoothDevice?, e: BaseError?) {
                log("✗ Set screen saver ($path): code=${e?.code} sub=${e?.subCode} ${e?.message}")
                if (withSlash) apply(d, storage, name, withSlash = false)
                else main.post { uploading = false; uploadStatus = "انبعثت بس ما انطبقت" }
            }
        })
    }

    /** Center-crop the image to fill exactly w x h. */
    private fun cropFill(src: Bitmap, w: Int, h: Int): Bitmap {
        val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
        val cw = (w / scale).toInt().coerceAtMost(src.width)
        val ch = (h / scale).toInt().coerceAtMost(src.height)
        val left = (src.width - cw) / 2
        val top = (src.height - ch) / 2
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, Rect(left, top, left + cw, top + ch), Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }
}
