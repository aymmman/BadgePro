package com.ayman.badgepro

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.content.ContextCompat

private val Purple = Color(0xFF7C5CFF)
private val Bg = Color(0xFF0F1020)
private val CardBg = Color(0xFF1A1B33)

class MainActivity : ComponentActivity() {
    private lateinit var ble: BadgeBle
    private lateinit var jl: JlLink
    private lateinit var screen: ScreenLink

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ble = BadgeBle(this)
        jl = JlLink(this) { ble.addLog(it) }
        screen = ScreenLink(this) { ble.addLog(it) }
        jl.onReady = { device ->
            ble.connectDevice(device, ble.connectedName.ifEmpty { "Z01" })
            window.decorView.postDelayed({ screen.readAll() }, 1500)
        }
        jl.onLost = { ble.disconnect() }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple, background = Bg, surface = CardBg,
                    onPrimary = Color.White, onSurface = Color.White, onBackground = Color.White
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App(ble, jl, screen) }
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) { jl.disconnect(); ble.disconnect() }
        super.onDestroy()
    }
}

private fun neededPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 31)
        arrayOf(
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

private fun hasPermissions(ctx: Context) = neededPermissions().all {
    ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
}

@Composable
fun App(ble: BadgeBle, jl: JlLink, screen: ScreenLink) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasPermissions(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = hasPermissions(ctx) }
    val enableBt = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    fun startScanFlow() {
        if (!granted) { permLauncher.launch(neededPermissions()); return }
        if (!ble.isBluetoothOn) {
            try { enableBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) {}
            return
        }
        ble.startScan()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header(ble, jl) }

        val linked = jl.connected || ble.state == LinkState.CONNECTED
        if (!linked) {
            item {
                Button(
                    onClick = { startScanFlow() },
                    enabled = ble.state != LinkState.CONNECTING,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        when (ble.state) {
                            LinkState.SCANNING -> "جاري البحث..."
                            LinkState.CONNECTING -> "جاري الاتصال..."
                            else -> "ابحث عن البادج"
                        }, fontSize = 16.sp
                    )
                }
                if (!granted) Text(
                    "التطبيق بحاجة لصلاحية البلوتوث. اضغط الزر واسمح بها.",
                    color = Color(0xFFFFC107), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                )
                Text(
                    "تأكد إن تطبيق BagiBagi مسكّر تمامًا قبل الاتصال.",
                    color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            items(ble.devices, key = { it.address }) { d ->
                DeviceRow(d) {
                    ble.markConnecting(d.name)
                    jl.connect(d.device)
                }
            }
        } else {
            item { ConnectedPanel(ble, jl, screen) }
        }

        item { LogPanel(ble) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Header(ble: BadgeBle, jl: JlLink) {
    Row(
        Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(Modifier.size(44.dp), shape = CircleShape, color = Purple) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("B", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("BadgePro", fontWeight = FontWeight.Bold, fontSize = 22.sp)
            val (label, color) = when (ble.state) {
                LinkState.CONNECTED -> "متصل بـ ${ble.connectedName}" to Color(0xFF4CAF50)
                LinkState.CONNECTING -> "جاري الاتصال..." to Color(0xFFFFC107)
                LinkState.SCANNING -> "جاري البحث..." to Color(0xFFFFC107)
                LinkState.IDLE -> "غير متصل" to Color.Gray
            }
            Text(label, color = color, fontSize = 13.sp)
            if (ble.state != LinkState.IDLE || jl.connected || jl.connecting) {
                Text(
                    "JieLi: " + when {
                        jl.connected -> "✅ متصل"
                        jl.connecting -> "⏳ جاري الاتصال والمصادقة"
                        else -> "❌ غير متصل"
                    } + "   |   مباشر: " + if (ble.state == LinkState.CONNECTED) "✅" else "❌",
                    color = Color.Gray, fontSize = 12.sp
                )
            }
        }
        if (ble.state == LinkState.SCANNING || ble.state == LinkState.CONNECTING) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
        }
    }
}

@Composable
fun DeviceRow(d: FoundDevice, onClick: () -> Unit) {
    val isBadge = d.name.startsWith("Z0")
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (isBadge) Color(0xFF2A2366) else CardBg),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.name + if (isBadge) "  ⭐" else "", fontWeight = FontWeight.SemiBold)
                Text(d.address, color = Color.Gray, fontSize = 12.sp)
            }
            Text("${d.rssi} dBm", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Purple)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

@Composable
fun Act(label: String, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, shape = RoundedCornerShape(12.dp)) { Text(label, fontSize = 13.sp) }
}

@Composable
fun ConnectedPanel(ble: BadgeBle, jl: JlLink, screen: ScreenLink) {
    var text by remember { mutableStateOf("مرحبا من BadgePro") }
    var hex by remember { mutableStateOf("88 88 01 01 00") }
    var newName by remember { mutableStateOf("") }
    var volume by remember { mutableFloatStateOf(8f) }
    var confirmReset by remember { mutableStateOf(false) }
    var showLab by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MTU: ${ble.mtu}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { jl.disconnect(); ble.disconnect() }) { Text("قطع الاتصال") }
        }
        if (jl.battery >= 0) {
            Text("🔋 البطارية: ${jl.battery}%", color = Color(0xFF8BE59B))
        }

        ScreenPanel(screen)

        OutlinedButton(onClick = { showLab = !showLab }, modifier = Modifier.fillMaxWidth()) {
            Text(if (showLab) "إخفاء المختبر المتقدم" else "🧪 المختبر المتقدم (أوامر التجربة)")
        }
        if (showLab) {
        JieLiPanel(ble, jl)
        if (ble.lastInfo.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF16351F))) {
                Text("آخر رد: ${ble.lastInfo}", Modifier.padding(12.dp), color = Color(0xFF8BE59B))
            }
        }

        Section("1. معلومات الجهاز (مباشر)") {
            Chips {
                Act("البطارية") { ble.send(Protocol.battery()) }
                Act("حالة الجهاز") { ble.send(Protocol.deviceState()) }
                Act("معلومات الشاشة") { ble.send(Protocol.wallpaperInfo()) }
                Act("MTU") { ble.send(Protocol.mtu()) }
                Act("قراءة الصوت") { ble.send(Protocol.getVolume()) }
            }
        }

        Section("2. نص على الشاشة (أهم تجربة)") {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("اكتب نص") }
            )
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("ابعث النص") { if (text.isNotBlank()) ble.sendText(text) }
                Act("تجربة إنجليزي") { ble.sendText("Hello from BadgePro") }
                Act("تجربة إشعار") { ble.sendText("واتساب: أحمد - وين صرت؟") }
            }
        }

        Section("3. عرض الصور والشاشة") {
            Text("تبديل الصور:", color = Color.Gray, fontSize = 13.sp)
            Chips {
                Act("افتراضي") { ble.send(Protocol.carouselDefault()) }
                Act("بالترتيب") { ble.send(Protocol.carouselOrdered()) }
                Act("عشوائي") { ble.send(Protocol.carouselShuffle()) }
                Act("اقرأ الوضع") { ble.send(Protocol.readCarousel()) }
            }
            Spacer(Modifier.height(8.dp))
            Text("إطفاء الشاشة تلقائيًا:", color = Color.Gray, fontSize = 13.sp)
            Chips {
                Act("5") { ble.send(Protocol.screenOff(0x0A)) }
                Act("10") { ble.send(Protocol.screenOff(0x0B)) }
                Act("15") { ble.send(Protocol.screenOff(0x0C)) }
            }
            Spacer(Modifier.height(8.dp))
            Chips { Act("رجّع الثيم الأصلي") { ble.send(Protocol.restoreTheme()) } }
        }

        Section("4. الصوت والتسجيل") {
            Text("مستوى الصوت: ${volume.toInt()}", color = Color.Gray, fontSize = 13.sp)
            Slider(value = volume, onValueChange = { volume = it }, valueRange = 0f..16f, steps = 15,
                onValueChangeFinished = { ble.send(Protocol.setVolume(volume.toInt())) })
            Chips {
                Act("ابدأ تسجيل") { ble.send(Protocol.startRecord()) }
                Act("وقّف تسجيل") { ble.send(Protocol.stopRecord()) }
                Act("دوّر على جهازي") { ble.send(Protocol.searchDevice(true)) }
                Act("وقّف البحث") { ble.send(Protocol.searchDevice(false)) }
            }
        }

        Section("5. اسم الجهاز") {
            OutlinedTextField(
                value = newName, onValueChange = { newName = it.take(20) },
                modifier = Modifier.fillMaxWidth(), label = { Text("اسم جديد (إنجليزي أفضل)") }
            )
            Spacer(Modifier.height(8.dp))
            Chips { Act("غيّر الاسم") { if (newName.isNotBlank()) ble.send(Protocol.rename(newName.trim())) } }
        }

        Section("6. مختبر الأوامر (Hex)") {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                OutlinedTextField(
                    value = hex, onValueChange = { hex = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("Hex bytes") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                )
            }
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("ابعث") {
                    val b = Protocol.parseHex(hex)
                    if (b == null) ble.addLog("Hex غير صحيح") else ble.send(b)
                }
            }
        }

        Section("⚠️ منطقة خطرة") {
            Text("إعادة ضبط المصنع بتمسح الصور والإعدادات من البادج.", color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { confirmReset = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))
            ) { Text("إعادة ضبط المصنع") }
        }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("متأكد؟") },
            text = { Text("رح تنمسح كل الصور والإعدادات من البادج.") },
            confirmButton = {
                TextButton(onClick = { confirmReset = false; ble.send(Protocol.resetFactory()) }) { Text("نعم، امسح") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun LogPanel(ble: BadgeBle) {
    val ctx = LocalContext.current
    Section("سجل الاتصال") {
        Row {
            Act("انسخ السجل") {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("BadgePro log", ble.logText()))
                Toast.makeText(ctx, "تم النسخ، الصقه لـ Claude", Toast.LENGTH_SHORT).show()
            }
            Spacer(Modifier.width(8.dp))
            Act("امسح") { ble.log.clear() }
        }
        Spacer(Modifier.height(8.dp))
        if (ble.services.isNotEmpty()) {
            Text("Services:", color = Color.Gray, fontSize = 12.sp)
            ble.services.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFB0B3FF)) }
            Spacer(Modifier.height(8.dp))
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(
                Modifier.fillMaxWidth().background(Color(0xFF0A0A16), RoundedCornerShape(10.dp)).padding(8.dp)
            ) {
                if (ble.log.isEmpty()) Text("No activity yet", color = Color.Gray, fontSize = 12.sp)
                ble.log.take(80).forEach { line ->
                    val c = when {
                        "RX" in line -> Color(0xFF8BE59B)
                        "TX" in line -> Color(0xFF9FB4FF)
                        else -> Color(0xFFCCCCCC)
                    }
                    Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = c)
                }
            }
        }
    }
}

@Composable
fun JieLiPanel(ble: BadgeBle, jl: JlLink) {
    var jlHex by remember { mutableStateOf("FF F7 FA 01 00") }
    var subtitle by remember { mutableStateOf("مرحبا! BadgePro") }

    if (!jl.connected) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2A12))) {
            Text(
                "قناة JieLi مش متصلة. الأوامر تحت ما رح تشتغل لحد ما تصير ✅ فوق.",
                Modifier.padding(12.dp), color = Color(0xFFFFC107), fontSize = 13.sp
            )
        }
    }

    Section("⭐ أ. التعابير (جرّبها أول)") {
        Chips {
            Act("😀 مبسوط") { jl.send(JlCmd.emote(0), "happy") }
            Act("😠 معصّب") { jl.send(JlCmd.emote(1), "angry") }
            Act("😢 زعلان") { jl.send(JlCmd.emote(2), "sad") }
        }
        Spacer(Modifier.height(6.dp))
        Text("نفس التعابير بتكرار مختلف:", color = Color.Gray, fontSize = 12.sp)
        Chips {
            Act("😀 ×0") { jl.send(JlCmd.emote(0, 0), "happy c0") }
            Act("😀 ×3") { jl.send(JlCmd.emote(0, 3), "happy c3") }
            Act("😀 ×255") { jl.send(JlCmd.emote(0, 255), "happy c255") }
        }
    }

    Section("ب. الثيمات") {
        Chips {
            Act("ثيم 1") { jl.send(JlCmd.themeDefault, "theme 1") }
            Act("ثيم 2") { jl.send(JlCmd.themeSecond, "theme 2") }
            Act("اقرأ الثيم") { jl.send(JlCmd.themeRead, "theme read") }
            Act("رجّع الأصلي") { jl.send(JlCmd.themeReset, "theme reset") }
        }
    }

    Section("ج. حالات المساعد الذكي") {
        Chips {
            Act("👂 بسمع") { jl.send(JlCmd.aiListening, "AI listening") }
            Act("🤔 بفكر") { jl.send(JlCmd.aiThinking, "AI thinking") }
            Act("⏹ خروج") { jl.send(JlCmd.aiExit, "AI exit") }
            Act("قاطع الرد") { jl.send(JlCmd.interruptReply, "interrupt") }
        }
    }

    Section("د. وضع الترجمة + نص على الشاشة") {
        Text(
            "بنشغّل وضع الترجمة عبر JieLi، وبعدها بنبعث النص عبر القناة المباشرة.",
            color = Color.Gray, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = subtitle, onValueChange = { subtitle = it },
            modifier = Modifier.fillMaxWidth(), label = { Text("النص") }
        )
        Spacer(Modifier.height(8.dp))
        Chips {
            Act("1) شغّل الترجمة") { jl.send(JlCmd.startTranslate, "translate start") }
            Act("2) ابعث النص") { if (subtitle.isNotBlank()) ble.sendText(subtitle) }
            Act("3) وقّف الترجمة") { jl.send(JlCmd.stopTranslate, "translate stop") }
        }
    }

    Section("هـ. عرض الصور وإطفاء الشاشة") {
        Chips {
            Act("بدون تبديل") { jl.send(JlCmd.carouselOff, "carousel off") }
            Act("بالترتيب") { jl.send(JlCmd.carouselOrdered, "carousel ordered") }
            Act("عشوائي") { jl.send(JlCmd.carouselShuffle, "carousel shuffle") }
            Act("اقرأ") { jl.send(JlCmd.carouselRead, "carousel read") }
        }
        Spacer(Modifier.height(6.dp))
        Text("إطفاء الشاشة:", color = Color.Gray, fontSize = 12.sp)
        Chips {
            Act("10ث") { jl.send(JlCmd.screenOff(10), "screen 10s") }
            Act("30ث") { jl.send(JlCmd.screenOff(30), "screen 30s") }
            Act("60ث") { jl.send(JlCmd.screenOff(60), "screen 60s") }
            Act("دايمًا شغالة") { jl.send(JlCmd.screenOffNever, "screen never") }
            Act("اقرأ") { jl.send(JlCmd.screenOffRead, "screen read") }
        }
    }

    Section("و. التسجيل والصوت") {
        Chips {
            Act("🎙 سجّل") { jl.send(JlCmd.startRecorder, "recorder start") }
            Act("⏹ وقّف") { jl.send(JlCmd.stopRecorder, "recorder stop") }
            Act("📝 اجتماع") { jl.send(JlCmd.startMeeting, "meeting start") }
            Act("⏹ اجتماع") { jl.send(JlCmd.stopMeeting, "meeting stop") }
            Act("🔊 صوت للبادج") { jl.send(JlCmd.audioToBadge, "audio→badge") }
            Act("📱 صوت للموبايل") { jl.send(JlCmd.audioToPhone, "audio→phone") }
            Act("اللغة") { jl.send(JlCmd.languageRead, "language read") }
        }
    }

    Section("ز. مختبر أوامر JieLi (Hex)") {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            OutlinedTextField(
                value = jlHex, onValueChange = { jlHex = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("Custom command bytes") },
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
            )
        }
        Spacer(Modifier.height(8.dp))
        Chips {
            Act("ابعث") {
                val b = Protocol.parseHex(jlHex)
                if (b == null) ble.addLog("Hex غير صحيح") else jl.send(b, "custom")
            }
            Act("ابعث بدون رد") {
                val b = Protocol.parseHex(jlHex)
                if (b == null) ble.addLog("Hex غير صحيح") else jl.send(b, "custom/noreply", needReply = false)
            }
        }
    }

    Text(
        "الأقسام تحت هي القناة المباشرة القديمة (للمقارنة).",
        color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
fun ScreenPanel(screen: ScreenLink) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) screen.uploadImage(uri)
    }
    var bright by remember { mutableFloatStateOf(60f) }
    var msgTitle by remember { mutableStateOf("BadgePro") }
    var msgBody by remember { mutableStateOf("مرحبا من تطبيقنا 👋") }

    Section("🖼️ صورة على البادج (الميزة الأساسية)") {
        val info = if (screen.screenW > 0)
            "الشاشة: ${screen.screenW}×${screen.screenH} ${if (screen.circular) "دائرية" else ""}  |  الشريحة: ${
                when (screen.chip) { 1 -> "701N"; 2 -> "707N"; else -> "?" }
            }"
        else "لسا ما وصلت معلومات الشاشة"
        Text(info, color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            enabled = !screen.uploading,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp)
        ) { Text(if (screen.uploading) "جاري الرفع..." else "📷 اختر صورة وابعتها", fontSize = 16.sp) }
        if (screen.uploading || screen.uploadStatus.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { screen.progress / 100f }, modifier = Modifier.fillMaxWidth())
            Text("${screen.uploadStatus}  ${screen.progress}%", color = Color.Gray, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Chips {
            Act("حدّث معلومات الشاشة") { screen.readAll() }
            Act("الصورة الحالية") { screen.currentSaver() }
            Act("الصور المحفوظة") { screen.browseSavers() }
        }
        if (screen.savers.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("اضغط على وحدة لتعرضها:", color = Color.Gray, fontSize = 12.sp)
            Chips {
                screen.savers.forEach { f ->
                    Act(f.path.substringAfterLast('/').ifEmpty { f.toString() }) { screen.useSaver(f) }
                }
            }
        }
    }

    Section("☀️ السطوع") {
        Text(
            "السطوع: ${bright.toInt()}%" + if (screen.brightness >= 0) "  (الجهاز: ${screen.brightness}%)" else "",
            color = Color.Gray, fontSize = 13.sp
        )
        Slider(
            value = bright, onValueChange = { bright = it }, valueRange = 0f..100f,
            onValueChangeFinished = { screen.changeBrightness(bright.toInt()) }
        )
    }

    Section("🔔 تجربة إشعار على الشاشة") {
        OutlinedTextField(
            value = msgTitle, onValueChange = { msgTitle = it.take(30) },
            modifier = Modifier.fillMaxWidth(), label = { Text("العنوان") }
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = msgBody, onValueChange = { msgBody = it.take(150) },
            modifier = Modifier.fillMaxWidth(), label = { Text("النص") }
        )
        Spacer(Modifier.height(8.dp))
        Chips { Act("ابعث الإشعار") { screen.pushMessage(msgTitle, msgBody) } }
    }
}
