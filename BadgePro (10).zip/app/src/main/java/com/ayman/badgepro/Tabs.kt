package com.ayman.badgepro

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.jieli.filebrowse.bean.RegFile
import kotlinx.coroutines.delay
import java.io.File

private val mainHandler = Handler(Looper.getMainLooper())

@Composable
fun UploadStatus(screen: ScreenLink) {
    if (screen.busy || screen.status.isNotEmpty()) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF15162B))) {
            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                Text(screen.status, color = Color.White, fontSize = 14.sp)
                if (screen.busy) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { screen.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("${screen.progress}%", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

// ======================= Photos =======================

@Composable
fun PhotosTab(screen: ScreenLink) {
    val ctx = LocalContext.current
    var studioSrc by remember { mutableStateOf<Bitmap?>(null) }
    var toDelete by remember { mutableStateOf<RegFile?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            val b = ScreenLink.decodeSampled(ctx, uri)
            if (b == null) Toast.makeText(ctx, "ما قدرت أفتح الصورة", Toast.LENGTH_SHORT).show() else studioSrc = b
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            enabled = !screen.busy,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("📷 صورة جديدة", fontSize = 17.sp) }

        UploadStatus(screen)

        Section("🗂️ الصور على البادج (${screen.savers.size})") {
            if (screen.savers.isEmpty()) Hint("ما في صور، أو لسا ما تحمّلت القائمة.")
            Chips {
                screen.savers.forEach { f ->
                    val name = screen.nameOf(f)
                    GalleryItem(
                        name = name,
                        thumb = screen.thumbOf(name),
                        current = name == screen.currentName,
                        onUse = { screen.use(f) },
                        onDelete = { toDelete = f }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Act("🔄 حدّث القائمة") { screen.browse() }
            Spacer(Modifier.height(4.dp))
            Hint("اضغط على صورة لعرضها، والضغطة على 🗑 بتحذفها من البادج.")
        }
    }

    studioSrc?.let { src ->
        StudioDialog(
            src = src, outSize = screen.screenW,
            onSend = { out -> studioSrc = null; screen.uploadBitmap(out) },
            onClose = { studioSrc = null }
        )
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف الصورة؟") },
            text = { Text("رح تنحذف ${screen.nameOf(f)} من البادج.") },
            confirmButton = { TextButton(onClick = { screen.delete(f); toDelete = null }) { Text("احذف") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun GalleryItem(name: String, thumb: File?, current: Boolean, onUse: () -> Unit, onDelete: () -> Unit) {
    val bmp = remember(thumb?.path, thumb?.lastModified()) { thumb?.let { BitmapFactory.decodeFile(it.path) } }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(92.dp)) {
        Box(
            Modifier.size(84.dp).clip(CircleShape)
                .background(Color(0xFF2A2B4A))
                .border(if (current) 3.dp else 1.dp, if (current) Good else Color.DarkGray, CircleShape)
                .clickable { onUse() },
            contentAlignment = Alignment.Center
        ) {
            if (bmp != null) Image(bmp.asImageBitmap(), name, contentScale = ContentScale.Crop, modifier = Modifier.size(84.dp))
            else Text("🖼️", fontSize = 28.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (current) "✓ معروضة" else name.removePrefix("VIE_"), fontSize = 11.sp, color = if (current) Good else Color.Gray)
            Text("  🗑", fontSize = 14.sp, modifier = Modifier.clickable { onDelete() })
        }
    }
}

// ======================= Animated =======================

@Composable
fun AnimTab(screen: ScreenLink) {
    val ctx = LocalContext.current
    var seconds by remember { mutableIntStateOf(3) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoDur by remember { mutableStateOf(0L) }
    var startSec by remember { mutableFloatStateOf(0f) }

    fun build(job: () -> List<Bitmap>) {
        screen.setBusy("تجهيز الإطارات...")
        Thread {
            try {
                val frames = job()
                mainHandler.post { screen.setBusy("ضغط الصورة المتحركة (${frames.size} إطار)...") }
                val gif = File(ctx.cacheDir, "anim.gif")
                GifMaker.encode(frames, gif)
                val thumb = frames.first()
                mainHandler.post { screen.failJob(""); screen.uploadGif(gif, thumb) }
            } catch (e: Exception) {
                mainHandler.post { screen.failJob("فشل: ${e.message}") }
            }
        }.start()
    }

    val gifPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) build { GifMaker.framesFromGif(ctx, uri, screen.screenW, seconds) }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) { videoUri = uri; videoDur = GifMaker.videoDurationMs(ctx, uri); startSec = 0f }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!screen.gifSupported) Hint("⚠️ يبدو إن البادج ما بيدعم الصور المتحركة، بس تقدر تجرّب.", Warn)

        Section("⏱️ طول المقطع") {
            Chips {
                listOf(2, 3, 4).forEach { s ->
                    Act(if (s == seconds) "✓ $s ثواني" else "$s ثواني") { seconds = s }
                }
            }
            Spacer(Modifier.height(6.dp))
            Hint("كل ما كان أقصر، كل ما وصل أسرع. 3 ثواني تقريبًا بتاخذ نص دقيقة لدقيقة إرسال.")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { gifPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.SingleMimeType("image/gif"))) },
                enabled = !screen.busy, modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(16.dp)
            ) { Text("🎞️ GIF") }
            Button(
                onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                enabled = !screen.busy, modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(16.dp)
            ) { Text("🎬 فيديو") }
        }

        UploadStatus(screen)

        videoUri?.let { uri ->
            Section("🎬 اختار المقطع من الفيديو") {
                val maxStart = ((videoDur / 1000f) - seconds).coerceAtLeast(0f)
                Text("يبدأ من الثانية: ${startSec.toInt()}  (طول الفيديو ${videoDur / 1000} ث)", color = Color.Gray, fontSize = 13.sp)
                if (maxStart > 0f) Slider(value = startSec.coerceAtMost(maxStart), onValueChange = { startSec = it }, valueRange = 0f..maxStart)
                Spacer(Modifier.height(6.dp))
                Chips {
                    Act("ابعت المقطع ✨", enabled = !screen.busy) {
                        val start = (startSec * 1000).toLong()
                        videoUri = null
                        build { GifMaker.framesFromVideo(ctx, uri, screen.screenW, start, seconds) }
                    }
                    Act("إلغاء") { videoUri = null }
                }
            }
        }
    }
}

// ======================= Notifications =======================

@Composable
fun NotifyTab(screen: ScreenLink) {
    val ctx = LocalContext.current
    val cfg = remember { NotifySettings(ctx) }
    var enabled by remember { mutableStateOf(cfg.enabled) }
    var groups by remember { mutableStateOf(cfg.groups) }
    var hide by remember { mutableStateOf(cfg.hideText) }
    var secs by remember { mutableIntStateOf(cfg.seconds) }
    var access by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            access = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
            delay(1500)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("🔐 صلاحية قراءة الإشعارات") {
            if (access) Text("✅ مفعّلة", color = Good)
            else {
                Hint("لازم تسمح لـ BadgePro يقرأ الإشعارات، من إعدادات الموبايل.", Warn)
                Spacer(Modifier.height(8.dp))
                Act("افتح الإعدادات") {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }

        Section("🔔 إشعارات على البادج") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("تشغيل", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { enabled = it; cfg.enabled = it })
            }
            Spacer(Modifier.height(6.dp))
            NotifyGroups.labels.forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = key in groups, onCheckedChange = { on ->
                        groups = if (on) groups + key else groups - key
                        cfg.groups = groups
                    })
                    Text(label, color = Color.White)
                }
            }
        }

        Section("🙈 الخصوصية والمدة") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("اعرض اسم المرسل بس", color = Color.White)
                    Hint("بدون نص الرسالة، لأنه البادج بيشوفه الناس")
                }
                Switch(checked = hide, onCheckedChange = { hide = it; cfg.hideText = it })
            }
            Spacer(Modifier.height(10.dp))
            Text("مدة العرض قبل ما ترجع صورتك:", color = Color.Gray, fontSize = 13.sp)
            Chips {
                listOf(10, 15, 30, 60).forEach { s ->
                    Act(if (s == secs) "✓ $s ث" else "$s ث") { secs = s; cfg.seconds = s }
                }
            }
        }

        Section("🧪 تجربة") {
            Hint("بيوصل الإشعار للبادج بعد حوالي 5 ثواني، لأنه بينبعث كصورة.")
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("جرّب إشعار واتساب", enabled = !screen.busy) {
                    screen.showNotification(NotifyGroups.WHATSAPP, "أحمد", if (hide) null else "وين صرت؟ 😄", secs)
                }
                Act("جرّب مكالمة", enabled = !screen.busy) {
                    screen.showNotification(NotifyGroups.CALLS, "أمي ❤️", null, secs)
                }
            }
        }

        Section("🔋 نصيحة مهمة") {
            Hint("عشان الإشعارات توصل والتطبيق مسكّر، استثني BadgePro من توفير البطارية.")
            Spacer(Modifier.height(8.dp))
            Act("إعدادات البطارية") {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}

// ======================= Settings =======================

@Composable
fun SettingsTab(screen: ScreenLink, onDisconnect: () -> Unit) {
    var bright by remember { mutableFloatStateOf(if (screen.brightness >= 0) screen.brightness.toFloat() else 70f) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("☀️ السطوع") {
            Text("${bright.toInt()}%", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Slider(value = bright, onValueChange = { bright = it }, valueRange = 5f..100f,
                onValueChangeFinished = { screen.changeBrightness(bright.toInt()) })
        }
        WallpaperLab(screen)
        Section("ℹ️ معلومات البادج") {
            Text("الشاشة: ${screen.screenW}×${screen.screenH} دائرية", color = Color.White)
            Text("الشريحة: JieLi ${if (screen.chip == 1) "701N" else "707N"}", color = Color.White)
            Text("البطارية: ${if (Badge.jl.battery >= 0) "${Badge.jl.battery}%" else "?"}", color = Color.White)
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("حدّث") { screen.readInfo() }
                Act("قطع الاتصال") { onDisconnect() }
            }
        }
        LogPanel()
    }
}

@Composable
fun LogPanel() {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Section("🧾 سجل الاتصال") {
        Chips {
            Act(if (open) "إخفاء" else "اعرض") { open = !open }
            Act("انسخ السجل") {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("BadgePro log", Badge.ble.logText()))
                Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
            }
            Act("امسح") { Badge.ble.log.clear() }
        }
        if (open) {
            Spacer(Modifier.height(8.dp))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(Modifier.fillMaxWidth().background(Color(0xFF0A0A16), RoundedCornerShape(10.dp)).padding(8.dp)) {
                    Badge.ble.log.take(80).forEach { line ->
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 10.sp,
                            color = if ("✗" in line) Color(0xFFFF8A80) else if ("✓" in line) Good else Color(0xFFCCCCCC))
                    }
                }
            }
        }
    }
}

@Composable
fun WallpaperLab(screen: ScreenLink) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            val b = ScreenLink.decodeSampled(ctx, uri)
            if (b != null) screen.uploadAsWallpaper(GifMaker.cropFill(b, screen.screenW))
        }
    }
    Section("🧪 تجربة شاشة الخلفية") {
        Hint("بنشوف إذا البادج عنده شاشة ثانية غير شاشة الصور. جرّب الأزرار بالترتيب وراقب البادج.")
        Spacer(Modifier.height(8.dp))
        Chips {
            Act("1) معلومات الشاشات") { screen.caseInfo() }
            Act("2) الخلفية الحالية") { screen.currentWallpaper() }
            Act("3) قائمة الخلفيات") { screen.browseWallpapers() }
            Act("4) أنيميشن التشغيل") { screen.currentBootAnim() }
        }
        Spacer(Modifier.height(8.dp))
        Hint("5) جرّب صورة موجودة كخلفية:")
        Chips {
            screen.savers.take(6).forEach { f ->
                val n = screen.nameOf(f)
                Act(n.removePrefix("VIE_")) { screen.useAsWallpaper(n) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Act("6) ارفع صورة جديدة كخلفية", enabled = !screen.busy) {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        if (screen.wallInfo.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF15162B))) {
                Text(screen.wallInfo, Modifier.padding(12.dp), color = Color.White, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
        UploadStatus(screen)
    }
}

// ======================= Voice (Phase A test) =======================

@Composable
fun VoiceTab(voice: VoiceLink) {
    val ctx = LocalContext.current
    var sample by remember { mutableStateOf("مرحبا أيمن، أنا مساعدك الذكي على البادج") }
    LaunchedEffect(Unit) {
        while (true) { voice.refreshSpeaker(); delay(3000) }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AiPanel(Badge.ai)
        Section("1) 🔊 سماعة البادج") {
            Text(if (voice.speakerOk) "✅ السماعة متصلة" else "❌ السماعة مش متصلة", color = if (voice.speakerOk) Good else Warn)
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("وصّل السماعة") { voice.connectSpeaker() }
                Act("إعدادات البلوتوث") {
                    ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.OutlinedTextField(
                value = sample, onValueChange = { sample = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("جملة تجربة") }
            )
            Spacer(Modifier.height(8.dp))
            Act("🔊 احكيها من البادج") { voice.speak(sample) }
            Spacer(Modifier.height(4.dp))
            Hint("إذا طلع الصوت من الموبايل بدل البادج، معناها السماعة مش متصلة.")
        }

        Section("2) 🎙️ مايك البادج") {
            Text(voice.status, color = Color.White, fontSize = 15.sp)
            if (voice.recording) {
                Spacer(Modifier.height(6.dp))
                Text("وصل ${voice.blocks} مقطع صوتي...", color = Good, fontSize = 13.sp)
            }
            if (voice.lastInfo.isNotEmpty()) Text(voice.lastInfo, color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("▶️ شغّل آخر تسجيل", enabled = voice.lastWav != null) { voice.playLast() }
                Act("ابدأ تسجيل يدوي") { voice.startManual() }
                Act("وقّف") { voice.stopManual() }
            }
            Spacer(Modifier.height(6.dp))
            Hint("الطريقة الأساسية: دبل كليك على زر البادج، احكي جملة، واستنى. التسجيل اليدوي احتياط إذا الزر ما اشتغل مع تطبيقنا.")
        }

        Section("3) 🎬 شاشات البادج المدمجة") {
            Hint("جرّبهم وراقب شاشة البادج:")
            Spacer(Modifier.height(6.dp))
            Chips {
                Act("🤔 Thinking") { voice.screenThinking() }
                Act("🗣️ Speaking") { voice.screenSpeaking() }
                Act("⏹ خروج") { voice.screenExit() }
            }
        }

        LogPanel()
    }
}


@Composable
fun AiPanel(ai: AiAssistant) {
    var key by remember { mutableStateOf(ai.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var enabled by remember { mutableStateOf(ai.enabled) }
    var oaVoice by remember { mutableStateOf(ai.openAiVoice) }
    var convo by remember { mutableStateOf(ai.conversation) }
    var vname by remember { mutableStateOf(ai.voiceName) }
    var typed by remember { mutableStateOf("شو أحسن أكلة أردنية؟") }
    var advanced by remember { mutableStateOf(false) }
    var chatM by remember { mutableStateOf(ai.chatModel) }
    var sttM by remember { mutableStateOf(ai.sttModel) }
    var ttsM by remember { mutableStateOf(ai.ttsModel) }
    var persona by remember { mutableStateOf(ai.persona) }

    Section("🤖 المساعد الذكي (ChatGPT)") {
        if (!ai.ready) {
            Hint("حط مفتاح OpenAI API (بيبلّش بـ sk-). بينحفظ مشفّر على موبايلك بس.", Warn)
            Spacer(Modifier.height(6.dp))
        }
        androidx.compose.material3.OutlinedTextField(
            value = key, onValueChange = { key = it.trim() }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), label = { Text("OpenAI API Key") },
            visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None
                else androidx.compose.ui.text.input.PasswordVisualTransformation()
        )
        Spacer(Modifier.height(6.dp))
        Chips {
            Act("💾 احفظ المفتاح") { ai.apiKey = key }
            Act(if (showKey) "إخفاء" else "إظهار") { showKey = !showKey }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("الدبل كليك بيشغّل المساعد", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = enabled, onCheckedChange = { enabled = it; ai.enabled = it })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("محادثة متواصلة", color = Color.White)
                Hint("بعد الجواب بيرجع يسمع لحاله، وبيطلع إذا سكتت 7 ثواني")
            }
            Switch(checked = convo, onCheckedChange = { convo = it; ai.conversation = it })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("صوت OpenAI الطبيعي", color = Color.White)
                Hint(if (oaVoice) "أحلى، بس بيزيد ثانية تقريبًا" else "صوت الموبايل: أسرع ومجاني")
            }
            Switch(checked = oaVoice, onCheckedChange = { oaVoice = it; ai.openAiVoice = it })
        }
        if (oaVoice) {
            Chips {
                AiAssistant.VOICES.forEach { v -> Act(if (v == vname) "✓ $v" else v) { vname = v; ai.voiceName = v } }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("🧪 جرّب بالكتابة:", color = Color.Gray, fontSize = 13.sp)
        androidx.compose.material3.OutlinedTextField(
            value = typed, onValueChange = { typed = it }, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Chips {
            Act(if (ai.busy) "⏳ بفكر..." else "اسأل", enabled = !ai.busy && ai.ready) { ai.ask(typed) }
            Act("امسح الذاكرة") { ai.clearMemory() }
        }

        if (ai.lastQuestion.isNotEmpty() || ai.lastAnswer.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF15162B))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    if (ai.lastQuestion.isNotEmpty()) Text("🗣️ ${ai.lastQuestion}", color = Color(0xFFB0B3FF), fontSize = 14.sp)
                    if (ai.lastAnswer.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("🤖 ${ai.lastAnswer}", color = Color.White, fontSize = 15.sp)
                    }
                    if (ai.lastTiming.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Hint("⏱️ ${ai.lastTiming}")
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Act(if (advanced) "إخفاء الإعدادات المتقدمة" else "⚙️ إعدادات متقدمة") { advanced = !advanced }
        if (advanced) {
            Spacer(Modifier.height(6.dp))
            androidx.compose.material3.OutlinedTextField(value = persona, onValueChange = { persona = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("شخصية المساعد") })
            androidx.compose.material3.OutlinedTextField(value = chatM, onValueChange = { chatM = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { Text("Chat model") })
            androidx.compose.material3.OutlinedTextField(value = sttM, onValueChange = { sttM = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { Text("Speech-to-text model") })
            androidx.compose.material3.OutlinedTextField(value = ttsM, onValueChange = { ttsM = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { Text("Voice model") })
            Spacer(Modifier.height(6.dp))
            Chips {
                Act("💾 احفظ") { ai.persona = persona; ai.chatModel = chatM; ai.sttModel = sttM; ai.ttsModel = ttsM }
                Act("رجّع الافتراضي") {
                    persona = AiAssistant.DEFAULT_PERSONA; chatM = "gpt-4o-mini"; sttM = "gpt-4o-mini-transcribe"; ttsM = "gpt-4o-mini-tts"
                    ai.persona = persona; ai.chatModel = chatM; ai.sttModel = sttM; ai.ttsModel = ttsM
                }
            }
        }
    }
}
