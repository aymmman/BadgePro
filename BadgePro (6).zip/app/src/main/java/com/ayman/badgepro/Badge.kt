package com.ayman.badgepro

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper

class BadgeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Badge.init(this)
    }
}

/** App-wide state shared by the UI and the notification service. */
@SuppressLint("StaticFieldLeak", "MissingPermission")
object Badge {
    lateinit var app: Context; private set
    lateinit var ble: BadgeBle; private set
    lateinit var jl: JlLink; private set
    lateinit var screen: ScreenLink; private set
    lateinit var prefs: SharedPreferences; private set
    private val main = Handler(Looper.getMainLooper())
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        app = context.applicationContext
        prefs = app.getSharedPreferences("badge", Context.MODE_PRIVATE)
        ble = BadgeBle(app)
        jl = JlLink(app) { log(it) }
        screen = ScreenLink(app) { log(it) }
        jl.onReady = { device ->
            prefs.edit().putString(KEY_LAST_ADDR, device.address).apply()
            main.postDelayed({ screen.onConnected() }, 1200)
        }
        jl.onLost = { ble.resetState() }
    }

    fun log(s: String) = ble.addLog(s)

    val lastAddress: String? get() = prefs.getString(KEY_LAST_ADDR, null)

    /** Reconnect to the last badge without scanning. */
    fun reconnectLast(): Boolean {
        val addr = lastAddress ?: return false
        if (jl.connected || jl.connecting) return true
        return try {
            val adapter = (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            if (adapter == null || !adapter.isEnabled) return false
            ble.markConnecting("Z01")
            jl.connect(adapter.getRemoteDevice(addr))
            true
        } catch (e: Exception) {
            log("Reconnect failed: ${e.message}"); false
        }
    }

    const val KEY_LAST_ADDR = "last_addr"
}
