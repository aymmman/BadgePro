package com.ayman.badgepro

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Badge.init(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple, background = Bg, surface = CardBg,
                    onPrimary = Color.White, onSurface = Color.White, onBackground = Color.White
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App() }
            }
        }
    }
}

private fun neededPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

private fun hasPermissions(ctx: Context) = neededPermissions().all {
    ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val ble = Badge.ble
    val jl = Badge.jl
    val screen = Badge.screen
    var granted by remember { mutableStateOf(hasPermissions(ctx)) }
    var tab by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasPermissions(ctx)
        if (granted) Badge.reconnectLast()
    }
    val enableBt = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}

    LaunchedEffect(Unit) {
        if (!granted) permLauncher.launch(neededPermissions())
        else if (!jl.connected) Badge.reconnectLast()
    }

    fun scan() {
        if (!granted) { permLauncher.launch(neededPermissions()); return }
        if (!ble.isBluetoothOn) {
            try { enableBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) {}
            return
        }
        ble.startScan()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header() }

        if (!jl.connected) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (Badge.lastAddress != null) {
                        Button(
                            onClick = { if (granted) Badge.reconnectLast() else permLauncher.launch(neededPermissions()) },
                            enabled = !jl.connecting,
                            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)
                        ) { Text(if (jl.connecting) "جاري الاتصال..." else "🔗 اتصل بالبادج تبعي", fontSize = 16.sp) }
                    }
                    OutlinedButton(
                        onClick = { scan() },
                        enabled = !jl.connecting && ble.state != LinkState.SCANNING,
                        modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)
                    ) { Text(if (ble.state == LinkState.SCANNING) "جاري البحث..." else "🔍 ابحث عن بادج") }
                    Hint("تأكد إن البلوتوث شغال، وإن تطبيق BagiBagi مش مثبّت أو مسكّر.")
                }
            }
            items(ble.devices, key = { it.address }) { d ->
                DeviceRow(d) {
                    ble.markConnecting(d.name)
                    jl.connect(d.device)
                }
            }
        } else {
            item {
                TabRow(selectedTabIndex = tab, containerColor = CardBg, contentColor = Color.White) {
                    listOf("🖼️ الصور", "🎞️ متحرك", "🔔 إشعارات", "⚙️").forEachIndexed { i, t ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 13.sp) })
                    }
                }
            }
            item {
                when (tab) {
                    0 -> PhotosTab(screen)
                    1 -> AnimTab(screen)
                    2 -> NotifyTab(screen)
                    else -> SettingsTab(screen) { jl.disconnect(); ble.resetState() }
                }
            }
        }
        if (!jl.connected) item { LogPanel() }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Header() {
    val jl = Badge.jl
    Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(Modifier.size(46.dp), shape = CircleShape, color = Purple) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("B", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("BadgePro", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White)
            val (label, color) = when {
                jl.connected -> "متصل ✅" + (if (jl.battery >= 0) "   🔋 ${jl.battery}%" else "") to Good
                jl.connecting -> "جاري الاتصال..." to Warn
                else -> "غير متصل" to Color.Gray
            }
            Text(label, color = color, fontSize = 13.sp)
        }
        if (jl.connecting || Badge.ble.state == LinkState.SCANNING) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
        }
    }
}

@Composable
fun DeviceRow(d: FoundDevice, onClick: () -> Unit) {
    val isBadge = d.name.startsWith("Z0")
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (isBadge) Color(0xFF2A2366) else CardBg),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.name + if (isBadge) "  ⭐" else "", fontWeight = FontWeight.SemiBold, color = Color.White)
                Text(d.address, color = Color.Gray, fontSize = 12.sp)
            }
            Text("${d.rssi} dBm", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
