package com.ayman.badgepro

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jieli.bluetooth.bean.base.BaseError
import com.jieli.bluetooth.bean.charging_case.ChargingCaseInfo
import com.jieli.bluetooth.bean.file.op.CreateFileParam
import com.jieli.bluetooth.bean.message.MessageInfo
import com.jieli.bluetooth.bean.settings.v0.ResourceInfo
import com.jieli.bluetooth.bean.settings.v0.SDKMessage
import com.jieli.bluetooth.bean.settings.v0.ScreenInfo
import com.jieli.bluetooth.bean.settings.v0.SettingFunction
import com.jieli.bluetooth.impl.rcsp.RCSPController
import com.jieli.bluetooth.impl.rcsp.charging_case.ChargingCaseOpImpl
import com.jieli.bluetooth.interfaces.rcsp.callback.OnRcspActionCallback
import com.jieli.bluetooth.interfaces.rcsp.callback.OnTaskStateListener
import com.jieli.bluetooth.interfaces.rcsp.charging_case.OnChargingCaseListener
import com.jieli.bmp_convert.BmpConvert
import com.jieli.filebrowse.bean.FileStruct
import com.jieli.filebrowse.bean.RegFile
import com.jieli.filebrowse.bean.SDCardBean
import com.jieli.filebrowse.interfaces.DeleteCallback
import com.jieli.lib.gif.GifConverter
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * Screen features of the Z01 through JieLi's official "colour screen" API:
 * upload images / GIFs as screen savers, list and delete them, brightness,
 * and temporary notification cards.
 */
@SuppressLint("MissingPermission")
class ScreenLink(context: Context, private val log: (String) -> Unit) {

    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val rc = RCSPController.getInstance()
    private val op: ChargingCaseOpImpl = ChargingCaseOpImpl.instance(rc.rcspOp)
    private val bmp = BmpConvert()
    private val prefs = ctx.getSharedPreferences("badge", Context.MODE_PRIVATE)
    private val thumbs = File(ctx.filesDir, "thumbs").apply { mkdirs() }

    var screenW by mutableStateOf(360); private set
    var screenH by mutableStateOf(360); private set
    var chip by mutableStateOf(SDKMessage.CHIP_707N); private set
    var gifSupported by mutableStateOf(true); private set
    var brightness by mutableStateOf(-1); private set
    var busy by mutableStateOf(false); private set
    var progress by mutableStateOf(0); private set
    var status by mutableStateOf(""); private set
    val savers = mutableStateListOf<RegFile>()

    /** Name of the image the user chose last (restored after a notification). */
    var currentName: String?
        get() = prefs.getString("current_saver", null)
        private set(v) { prefs.edit().putString("current_saver", v).apply() }

    private var pendingNote: Triple<String, String, String?>? = null
    private var pendingNoteSecs = 15

    private val listener = object : OnChargingCaseListener {
        override fun onInit(device: BluetoothDevice?, state: Int) {
            log("Screen init state = $state")
        }
        override fun onChargingCaseInfoChange(device: BluetoothDevice?, func: Int, info: ChargingCaseInfo?) {
            if (info != null && func == ChargingCaseInfo.FUNC_BRIGHTNESS) main.post { brightness = info.brightness }
        }
        override fun onChargingCaseEvent(device: BluetoothDevice?, function: SettingFunction?) {}
    }

    init { op.addOnChargingCaseListener(listener) }

    private val device: BluetoothDevice? get() = rc.usingDevice
    val connected: Boolean get() = Badge.jl.connected && device != null

    private fun <T> cb(label: String, ok: (T?) -> Unit = {}) = object : OnRcspActionCallback<T> {
        override fun onSuccess(d: BluetoothDevice?, result: T) {
            log("✓ $label: ${result ?: "ok"}"); main.post { ok(result) }
        }
        override fun onError(d: BluetoothDevice?, e: BaseError?) {
            log("✗ $label: code=${e?.code} sub=${e?.subCode} ${e?.message ?: ""}")
        }
    }

    // ---------------- Connection ----------------

    fun onConnected() {
        readInfo()
        main.postDelayed({ browse() }, 800)
        main.postDelayed({
            val p = pendingNote
            if (p != null) { pendingNote = null; showNotification(p.first, p.second, p.third, pendingNoteSecs) }
        }, 1800)
    }

    fun readInfo() {
        val d = device ?: return
        op.readSDKMessage(d, cb<SDKMessage>("SDK info") { m -> if (m != null) { chip = m.chip; gifSupported = m.isSupportGif || m.chip == SDKMessage.CHIP_707N } })
        op.readScreenInfo(d, cb<ScreenInfo>("Screen info") { s -> if (s != null && s.width > 0) { screenW = s.width; screenH = s.height } })
        op.getBrightness(d, cb<Int>("Brightness") { b -> if (b != null) brightness = b })
    }

    fun changeBrightness(value: Int) {
        val d = device ?: return
        op.setBrightness(d, value.coerceIn(0, 100), cb<Boolean>("Brightness $value") { brightness = value })
    }

    // ---------------- Gallery ----------------

    private fun flash(): SDCardBean? {
        val d = device ?: return null
        val list = op.getOnlineStorages(d).orEmpty().ifEmpty { op.fileOp.onlineStorage.orEmpty() }
        return list.firstOrNull { it.isFlash && it.isOnline } ?: list.firstOrNull()
    }

    fun browse(after: (() -> Unit)? = null) {
        val d = device ?: return
        val s = flash() ?: run { log("✗ No storage on badge"); return }
        op.browseScreenSavers(d, s.devHandler, object : OnRcspActionCallback<List<RegFile>> {
            override fun onSuccess(dev: BluetoothDevice?, list: List<RegFile>?) {
                log("✓ Badge has ${list?.size ?: 0} image(s)")
                main.post {
                    savers.clear(); if (list != null) savers.addAll(list.filter { !nameOf(it).startsWith(NOTE_PREFIX) })
                    after?.invoke()
                }
            }
            override fun onError(dev: BluetoothDevice?, e: BaseError?) {
                log("✗ Browse: ${e?.subCode} ${e?.message}"); main.post { after?.invoke() }
            }
        })
    }

    fun nameOf(f: RegFile): String = f.path.substringAfterLast('/')
    fun thumbOf(name: String): File? = File(thumbs, "$name.png").takeIf { it.exists() }

    fun use(f: RegFile) {
        val d = device ?: return
        val s = flash() ?: return
        val name = nameOf(f)
        op.setCurrentScreenSaver(d, s.devHandler, "/$name", cb<Boolean>("Show $name") { currentName = name })
    }

    fun delete(f: RegFile) {
        val d = device ?: return
        val s = flash() ?: return
        val name = nameOf(f)
        if (name == currentName) { status = "ما بتقدر تحذف الصورة المعروضة حاليًا"; return }
        deleteByName(d, s, name, f.cluster) {
            File(thumbs, "$name.png").delete()
            browse()
        }
    }

    private fun deleteByName(d: BluetoothDevice, s: SDCardBean, name: String, cluster: Int, done: () -> Unit) {
        val info = ResourceInfo(s.devHandler, cluster, 0.toShort(), "/$name")
        op.deleteResources(d, listOf(info), object : DeleteCallback {
            override fun onSuccess(fs: FileStruct?) { log("✓ Deleted $name") }
            override fun onError(code: Int, fs: FileStruct?) { log("✗ Delete $name: $code") }
            override fun onFinish() { main.post { done() } }
        })
    }

    // ---------------- Uploads ----------------

    private fun newName(prefix: String): String {
        val n = java.lang.Long.toString(System.currentTimeMillis() % 1_679_616, 36).uppercase().padStart(4, '0')
        return prefix + n
    }

    /** Upload a ready square bitmap (from the studio) and show it. */
    fun uploadBitmap(src: Bitmap) {
        if (busy) return
        val d = device ?: run { status = "البادج مش متصل"; return }
        startJob("تجهيز الصورة...")
        worker.execute {
            try {
                val name = newName("VIE_")
                val file = convertImage(src, name)
                saveThumb(name, src)
                main.post { transfer(d, file, asNote = false) }
            } catch (e: Exception) { fail("فشل التجهيز: ${e.message}") }
        }
    }

    /** Upload a GIF file produced by GifMaker. */
    fun uploadGif(gif: File, thumb: Bitmap) {
        if (busy) return
        val d = device ?: run { status = "البادج مش متصل"; return }
        startJob("تحويل الصورة المتحركة...")
        worker.execute {
            try {
                val name = newName("VIE_")
                val gifChip = if (chip == SDKMessage.CHIP_701N) GifConverter.CHIP_701N else GifConverter.CHIP_707N
                val r = GifConverter.getInstance().gif2Bin(gif.path, GifConverter.MODE_LOW_COMPRESSION_RATE, gifChip)
                if (!r.isSuccess) throw IllegalStateException("${r.code} ${r.message}")
                val out = File(workDir(), name)
                out.writeBytes(r.gifBin.data)
                log("GIF ready: ${gif.length() / 1024} KB → ${out.length() / 1024} KB on badge")
                saveThumb(name, thumb)
                main.post { transfer(d, out, asNote = false) }
            } catch (e: Exception) { fail("فشل تحويل GIF: ${e.message}") }
        }
    }

    fun setBusy(text: String) { startJob(text) }
    fun failJob(text: String) { fail(text) }

    private fun startJob(text: String) { busy = true; progress = 0; status = text }
    private fun fail(text: String) {
        if (text.isNotEmpty()) log("✗ $text")
        main.post { busy = false; status = text }
    }

    private fun workDir() = File(ctx.cacheDir, "upload").apply { mkdirs() }

    private fun convertImage(src: Bitmap, name: String): File {
        val dir = workDir()
        val png = File(dir, "src_$name.png")
        val scaled = if (src.width != screenW || src.height != screenH)
            Bitmap.createScaledBitmap(src, screenW, screenH, true) else src
        FileOutputStream(png).use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val out = File(dir, name)
        val type = if (chip == SDKMessage.CHIP_701N) BmpConvert.TYPE_701N_RGB else BmpConvert.TYPE_707N_RGB
        val ret = bmp.bitmapConvertBlock(type, png.path, out.path)
        png.delete()
        if (ret <= 0 || !out.exists()) throw IllegalStateException("convert ($ret)")
        return out
    }

    private fun saveThumb(name: String, b: Bitmap) {
        try {
            val t = Bitmap.createScaledBitmap(b, 160, 160, true)
            FileOutputStream(File(thumbs, "$name.png")).use { t.compress(Bitmap.CompressFormat.PNG, 90, it) }
        } catch (_: Exception) {}
    }

    private fun transfer(d: BluetoothDevice, file: File, asNote: Boolean, after: ((Boolean) -> Unit)? = null) {
        val storage = flash() ?: run { fail("ما لقيت ذاكرة بالبادج"); after?.invoke(false); return }
        if (!asNote) status = "جاري الإرسال..."
        op.fileOp.createBigFile(CreateFileParam(d, file, storage), object : OnTaskStateListener {
            override fun onStart() {}
            override fun onProgress(p: Int) { if (!asNote) main.post { progress = p } }
            override fun onStop() {
                val name = file.name
                op.setCurrentScreenSaver(d, storage.devHandler, "/$name", object : OnRcspActionCallback<Boolean> {
                    override fun onSuccess(dev: BluetoothDevice?, ok: Boolean?) {
                        log("✓ Showing $name")
                        file.delete()
                        main.post {
                            if (!asNote) { currentName = name; busy = false; progress = 100; status = "✅ تمت!"; browse() }
                            after?.invoke(true)
                        }
                    }
                    override fun onError(dev: BluetoothDevice?, e: BaseError?) {
                        file.delete()
                        fail("انبعثت بس ما انعرضت (${e?.subCode})"); main.post { after?.invoke(false) }
                    }
                })
            }
            override fun onCancel(reason: Int) { file.delete(); fail("انلغى"); main.post { after?.invoke(false) } }
            override fun onError(code: Int, message: String?) {
                file.delete(); fail("خطأ بالإرسال ($code)"); main.post { after?.invoke(false) }
            }
        })
    }

    // ---------------- Notifications ----------------

    /** Show a notification card, then restore the user's image after [seconds]. */
    fun showNotification(group: String, title: String, text: String?, seconds: Int) {
        main.post {
            val d = device
            if (d == null || !Badge.jl.connected) {
                pendingNote = Triple(group, title, text); pendingNoteSecs = seconds
                Badge.reconnectLast()
                return@post
            }
            if (busy) { pendingNote = Triple(group, title, text); pendingNoteSecs = seconds; return@post }
            busy = true
            worker.execute {
                try {
                    val card = CardRenderer.render(screenW, group, title, text)
                    val name = newName(NOTE_PREFIX)
                    val file = convertImage(card, name)
                    main.post {
                        transfer(d, file, asNote = true) { ok ->
                            if (!ok) { busy = false; return@transfer }
                            main.postDelayed({ restoreAfterNote(d, name) }, seconds * 1000L)
                        }
                    }
                } catch (e: Exception) { fail("Notification: ${e.message}") }
            }
        }
    }

    private fun restoreAfterNote(d: BluetoothDevice, noteName: String) {
        val s = flash() ?: run { busy = false; return }
        val back = currentName
        val finish = {
            // remove the card file so it doesn't fill the badge
            op.browseScreenSavers(d, s.devHandler, object : OnRcspActionCallback<List<RegFile>> {
                override fun onSuccess(dev: BluetoothDevice?, list: List<RegFile>?) {
                    val notes = list.orEmpty().filter { nameOf(it).startsWith(NOTE_PREFIX) }
                    if (notes.isEmpty()) { main.post { busy = false; flushPending() }; return }
                    val infos = notes.map { ResourceInfo(s.devHandler, it.cluster, 0.toShort(), "/" + nameOf(it)) }
                    op.deleteResources(d, infos, object : DeleteCallback {
                        override fun onSuccess(fs: FileStruct?) {}
                        override fun onError(code: Int, fs: FileStruct?) { log("✗ Card cleanup $code") }
                        override fun onFinish() { main.post { busy = false; flushPending() } }
                    })
                }
                override fun onError(dev: BluetoothDevice?, e: BaseError?) { main.post { busy = false; flushPending() } }
            })
        }
        if (back == null) { finish(); return }
        op.setCurrentScreenSaver(d, s.devHandler, "/$back", object : OnRcspActionCallback<Boolean> {
            override fun onSuccess(dev: BluetoothDevice?, ok: Boolean?) { log("✓ Restored $back"); finish() }
            override fun onError(dev: BluetoothDevice?, e: BaseError?) { log("✗ Restore failed ${e?.subCode}"); finish() }
        })
    }

    private fun flushPending() {
        val p = pendingNote ?: return
        pendingNote = null
        showNotification(p.first, p.second, p.third, pendingNoteSecs)
    }

    /** Test helper: the official message API (not supported by Z01 firmware). */
    fun pushOfficialMessage(title: String, content: String) {
        val d = device ?: return
        op.pushMessageInfo(d, MessageInfo("com.ayman.badgepro", MessageInfo.FLAG_DEFAULT, title, content, System.currentTimeMillis()), cb<Boolean>("Push message"))
    }

    companion object {
        const val NOTE_PREFIX = "NTF_"

        fun decodeSampled(ctx: Context, uri: Uri, maxSide: Int = 1600): Bitmap? {
            return try {
                if (android.os.Build.VERSION.SDK_INT >= 28) {
                    val src = android.graphics.ImageDecoder.createSource(ctx.contentResolver, uri)
                    android.graphics.ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                        dec.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                        val big = maxOf(info.size.width, info.size.height)
                        if (big > maxSide) {
                            val f = maxSide.toFloat() / big
                            dec.setTargetSize((info.size.width * f).toInt(), (info.size.height * f).toInt())
                        }
                    }
                } else {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                    var sample = 1
                    while (maxOf(o.outWidth, o.outHeight) / sample > maxSide) sample *= 2
                    ctx.contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
                    }
                }
            } catch (e: Exception) { null }
        }
    }
}
