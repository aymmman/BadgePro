package com.ayman.badgepro

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.jieli.filebrowse.bean.RegFile
import kotlinx.coroutines.delay
import java.io.File

private val mainHandler = Handler(Looper.getMainLooper())

@Composable
fun UploadStatus(screen: ScreenLink) {
    if (screen.busy || screen.status.isNotEmpty()) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF15162B))) {
            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                Text(screen.status, color = Color.White, fontSize = 14.sp)
                if (screen.busy) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { screen.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("${screen.progress}%", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

// ======================= Photos =======================

@Composable
fun PhotosTab(screen: ScreenLink) {
    val ctx = LocalContext.current
    var studioSrc by remember { mutableStateOf<Bitmap?>(null) }
    var toDelete by remember { mutableStateOf<RegFile?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            val b = ScreenLink.decodeSampled(ctx, uri)
            if (b == null) Toast.makeText(ctx, "ما قدرت أفتح الصورة", Toast.LENGTH_SHORT).show() else studioSrc = b
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            enabled = !screen.busy,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("📷 صورة جديدة", fontSize = 17.sp) }

        UploadStatus(screen)

        Section("🗂️ الصور على البادج (${screen.savers.size})") {
            if (screen.savers.isEmpty()) Hint("ما في صور، أو لسا ما تحمّلت القائمة.")
            Chips {
                screen.savers.forEach { f ->
                    val name = screen.nameOf(f)
                    GalleryItem(
                        name = name,
                        thumb = screen.thumbOf(name),
                        current = name == screen.currentName,
                        onUse = { screen.use(f) },
                        onDelete = { toDelete = f }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Act("🔄 حدّث القائمة") { screen.browse() }
            Spacer(Modifier.height(4.dp))
            Hint("اضغط على صورة لعرضها، والضغطة على 🗑 بتحذفها من البادج.")
        }
    }

    studioSrc?.let { src ->
        StudioDialog(
            src = src, outSize = screen.screenW,
            onSend = { out -> studioSrc = null; screen.uploadBitmap(out) },
            onClose = { studioSrc = null }
        )
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف الصورة؟") },
            text = { Text("رح تنحذف ${screen.nameOf(f)} من البادج.") },
            confirmButton = { TextButton(onClick = { screen.delete(f); toDelete = null }) { Text("احذف") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun GalleryItem(name: String, thumb: File?, current: Boolean, onUse: () -> Unit, onDelete: () -> Unit) {
    val bmp = remember(thumb?.path, thumb?.lastModified()) { thumb?.let { BitmapFactory.decodeFile(it.path) } }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(92.dp)) {
        Box(
            Modifier.size(84.dp).clip(CircleShape)
                .background(Color(0xFF2A2B4A))
                .border(if (current) 3.dp else 1.dp, if (current) Good else Color.DarkGray, CircleShape)
                .clickable { onUse() },
            contentAlignment = Alignment.Center
        ) {
            if (bmp != null) Image(bmp.asImageBitmap(), name, contentScale = ContentScale.Crop, modifier = Modifier.size(84.dp))
            else Text("🖼️", fontSize = 28.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (current) "✓ معروضة" else name.removePrefix("VIE_"), fontSize = 11.sp, color = if (current) Good else Color.Gray)
            Text("  🗑", fontSize = 14.sp, modifier = Modifier.clickable { onDelete() })
        }
    }
}

// ======================= Animated =======================

@Composable
fun AnimTab(screen: ScreenLink) {
    val ctx = LocalContext.current
    var seconds by remember { mutableIntStateOf(3) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoDur by remember { mutableStateOf(0L) }
    var startSec by remember { mutableFloatStateOf(0f) }

    fun build(job: () -> List<Bitmap>) {
        screen.setBusy("تجهيز الإطارات...")
        Thread {
            try {
                val frames = job()
                mainHandler.post { screen.setBusy("ضغط الصورة المتحركة (${frames.size} إطار)...") }
                val gif = File(ctx.cacheDir, "anim.gif")
                GifMaker.encode(frames, gif)
                val thumb = frames.first()
                mainHandler.post { screen.failJob(""); screen.uploadGif(gif, thumb) }
            } catch (e: Exception) {
                mainHandler.post { screen.failJob("فشل: ${e.message}") }
            }
        }.start()
    }

    val gifPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) build { GifMaker.framesFromGif(ctx, uri, screen.screenW, seconds) }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) { videoUri = uri; videoDur = GifMaker.videoDurationMs(ctx, uri); startSec = 0f }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (!screen.gifSupported) Hint("⚠️ يبدو إن البادج ما بيدعم الصور المتحركة، بس تقدر تجرّب.", Warn)

        Section("⏱️ طول المقطع") {
            Chips {
                listOf(2, 3, 4).forEach { s ->
                    Act(if (s == seconds) "✓ $s ثواني" else "$s ثواني") { seconds = s }
                }
            }
            Spacer(Modifier.height(6.dp))
            Hint("كل ما كان أقصر، كل ما وصل أسرع. 3 ثواني تقريبًا بتاخذ نص دقيقة لدقيقة إرسال.")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { gifPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.SingleMimeType("image/gif"))) },
                enabled = !screen.busy, modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(16.dp)
            ) { Text("🎞️ GIF") }
            Button(
                onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                enabled = !screen.busy, modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(16.dp)
            ) { Text("🎬 فيديو") }
        }

        UploadStatus(screen)

        videoUri?.let { uri ->
            Section("🎬 اختار المقطع من الفيديو") {
                val maxStart = ((videoDur / 1000f) - seconds).coerceAtLeast(0f)
                Text("يبدأ من الثانية: ${startSec.toInt()}  (طول الفيديو ${videoDur / 1000} ث)", color = Color.Gray, fontSize = 13.sp)
                if (maxStart > 0f) Slider(value = startSec.coerceAtMost(maxStart), onValueChange = { startSec = it }, valueRange = 0f..maxStart)
                Spacer(Modifier.height(6.dp))
                Chips {
                    Act("ابعت المقطع ✨", enabled = !screen.busy) {
                        val start = (startSec * 1000).toLong()
                        videoUri = null
                        build { GifMaker.framesFromVideo(ctx, uri, screen.screenW, start, seconds) }
                    }
                    Act("إلغاء") { videoUri = null }
                }
            }
        }
    }
}

// ======================= Notifications =======================

@Composable
fun NotifyTab(screen: ScreenLink) {
    val ctx = LocalContext.current
    val cfg = remember { NotifySettings(ctx) }
    var enabled by remember { mutableStateOf(cfg.enabled) }
    var groups by remember { mutableStateOf(cfg.groups) }
    var hide by remember { mutableStateOf(cfg.hideText) }
    var secs by remember { mutableIntStateOf(cfg.seconds) }
    var access by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            access = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
            delay(1500)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("🔐 صلاحية قراءة الإشعارات") {
            if (access) Text("✅ مفعّلة", color = Good)
            else {
                Hint("لازم تسمح لـ BadgePro يقرأ الإشعارات، من إعدادات الموبايل.", Warn)
                Spacer(Modifier.height(8.dp))
                Act("افتح الإعدادات") {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }

        Section("🔔 إشعارات على البادج") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("تشغيل", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { enabled = it; cfg.enabled = it })
            }
            Spacer(Modifier.height(6.dp))
            NotifyGroups.labels.forEach { (key, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = key in groups, onCheckedChange = { on ->
                        groups = if (on) groups + key else groups - key
                        cfg.groups = groups
                    })
                    Text(label, color = Color.White)
                }
            }
        }

        Section("🙈 الخصوصية والمدة") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("اعرض اسم المرسل بس", color = Color.White)
                    Hint("بدون نص الرسالة، لأنه البادج بيشوفه الناس")
                }
                Switch(checked = hide, onCheckedChange = { hide = it; cfg.hideText = it })
            }
            Spacer(Modifier.height(10.dp))
            Text("مدة العرض قبل ما ترجع صورتك:", color = Color.Gray, fontSize = 13.sp)
            Chips {
                listOf(10, 15, 30, 60).forEach { s ->
                    Act(if (s == secs) "✓ $s ث" else "$s ث") { secs = s; cfg.seconds = s }
                }
            }
        }

        Section("🧪 تجربة") {
            Hint("بيوصل الإشعار للبادج بعد حوالي 5 ثواني، لأنه بينبعث كصورة.")
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("جرّب إشعار واتساب", enabled = !screen.busy) {
                    screen.showNotification(NotifyGroups.WHATSAPP, "أحمد", if (hide) null else "وين صرت؟ 😄", secs)
                }
                Act("جرّب مكالمة", enabled = !screen.busy) {
                    screen.showNotification(NotifyGroups.CALLS, "أمي ❤️", null, secs)
                }
            }
        }

        Section("🔋 نصيحة مهمة") {
            Hint("عشان الإشعارات توصل والتطبيق مسكّر، استثني BadgePro من توفير البطارية.")
            Spacer(Modifier.height(8.dp))
            Act("إعدادات البطارية") {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}

// ======================= Settings =======================

@Composable
fun SettingsTab(screen: ScreenLink, onDisconnect: () -> Unit) {
    var bright by remember { mutableFloatStateOf(if (screen.brightness >= 0) screen.brightness.toFloat() else 70f) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Section("☀️ السطوع") {
            Text("${bright.toInt()}%", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Slider(value = bright, onValueChange = { bright = it }, valueRange = 5f..100f,
                onValueChangeFinished = { screen.changeBrightness(bright.toInt()) })
        }
        Section("ℹ️ معلومات البادج") {
            Text("الشاشة: ${screen.screenW}×${screen.screenH} دائرية", color = Color.White)
            Text("الشريحة: JieLi ${if (screen.chip == 1) "701N" else "707N"}", color = Color.White)
            Text("البطارية: ${if (Badge.jl.battery >= 0) "${Badge.jl.battery}%" else "?"}", color = Color.White)
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("حدّث") { screen.readInfo() }
                Act("قطع الاتصال") { onDisconnect() }
            }
        }
        LogPanel()
    }
}

@Composable
fun LogPanel() {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Section("🧾 سجل الاتصال") {
        Chips {
            Act(if (open) "إخفاء" else "اعرض") { open = !open }
            Act("انسخ السجل") {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("BadgePro log", Badge.ble.logText()))
                Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
            }
            Act("امسح") { Badge.ble.log.clear() }
        }
        if (open) {
            Spacer(Modifier.height(8.dp))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(Modifier.fillMaxWidth().background(Color(0xFF0A0A16), RoundedCornerShape(10.dp)).padding(8.dp)) {
                    Badge.ble.log.take(80).forEach { line ->
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 10.sp,
                            color = if ("✗" in line) Color(0xFFFF8A80) else if ("✓" in line) Good else Color(0xFFCCCCCC))
                    }
                }
            }
        }
    }
}
