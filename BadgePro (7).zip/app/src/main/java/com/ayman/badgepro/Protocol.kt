package com.ayman.badgepro

import java.util.UUID

/**
 * Direct GATT protocol for the Z01 badge (JieLi variant).
 * Frame: 0x88 0x88, cmd, type (0x01 = request), length, data bytes
 */
object Protocol {
    val SERVICE: UUID = UUID.fromString("0000df97-0000-1000-8000-00805f9b34fb")
    val WRITE: UUID = UUID.fromString("0000df98-0000-1000-8000-00805f9b34fb")
    val NOTIFY: UUID = UUID.fromString("0000df99-0000-1000-8000-00805f9b34fb")
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private const val H = 0x88.toByte()

    const val CMD_BATTERY = 0x01
    const val CMD_SEARCH_DEVICE = 0x0A
    const val CMD_GET_VOLUME = 0x0B
    const val CMD_SET_VOLUME = 0x0C
    const val CMD_DEVICE_STATE = 0x0E
    const val CMD_SET_NAME = 0x09
    const val CMD_TEXT = 0x11
    const val CMD_RESET_FACTORY = 0x12
    const val CMD_MTU = 0x17
    const val CMD_BADGE = 0x18 // carousel / screen-off / theme sub-commands

    fun frame(cmd: Int, data: ByteArray = ByteArray(0)): ByteArray =
        byteArrayOf(H, H, cmd.toByte(), 0x01, data.size.toByte()) + data

    fun battery() = frame(CMD_BATTERY)
    fun deviceState() = frame(CMD_DEVICE_STATE)
    fun mtu() = frame(CMD_MTU)
    fun getVolume() = frame(CMD_GET_VOLUME)
    fun setVolume(v: Int) = frame(CMD_SET_VOLUME, byteArrayOf(v.coerceIn(0, 16).toByte()))
    fun searchDevice(on: Boolean) = frame(CMD_SEARCH_DEVICE, byteArrayOf(if (on) 1 else 0))
    fun wallpaperInfo() = frame(CMD_BADGE)
    fun resetFactory() = frame(CMD_RESET_FACTORY)

    fun rename(name: String): ByteArray {
        val b = name.toByteArray(Charsets.UTF_8)
        return frame(CMD_SET_NAME, b.copyOf(minOf(b.size, 20)))
    }

    // Badge sub-commands (cmd 0x18, one data byte)
    fun carouselDefault() = frame(CMD_BADGE, byteArrayOf(0x04))
    fun carouselOrdered() = frame(CMD_BADGE, byteArrayOf(0x05))
    fun carouselShuffle() = frame(CMD_BADGE, byteArrayOf(0x06))
    fun readCarousel() = frame(CMD_BADGE, byteArrayOf(0x08))
    fun restoreTheme() = frame(CMD_BADGE, byteArrayOf(0x09))
    fun screenOff(code: Int) = frame(CMD_BADGE, byteArrayOf(code.toByte())) // 0x0A=5, 0x0B=10, 0x0C=15
    fun startRecord() = frame(CMD_BADGE, byteArrayOf(0x00))
    fun stopRecord() = frame(CMD_BADGE, byteArrayOf(0x01))

    /**
     * Text frames, same layout as the original app:
     * 88 88 11 01, len+5, totalHi, totalLo, idxHi, idxLo, len, then the UTF-8 payload
     * Each chunk is split on character boundaries so Arabic never breaks mid-letter.
     */
    fun textFrames(text: String, maxPayload: Int): List<ByteArray> {
        val chunks = mutableListOf<ByteArray>()
        var cur = ByteArray(0)
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            val bytes = String(Character.toChars(cp)).toByteArray(Charsets.UTF_8)
            if (cur.size + bytes.size > maxPayload && cur.isNotEmpty()) {
                chunks += cur; cur = ByteArray(0)
            }
            cur += bytes
            i += Character.charCount(cp)
        }
        if (cur.isNotEmpty()) chunks += cur
        return chunks.map { p ->
            val len = p.size
            byteArrayOf(
                H, H, CMD_TEXT.toByte(), 0x01,
                (len + 5).toByte(),
                ((len shr 8) and 0xFF).toByte(), (len and 0xFF).toByte(),
                0, 0,
                len.toByte()
            ) + p
        }
    }

    fun parseHex(s: String): ByteArray? {
        val clean = s.replace("0x", "", true).replace(Regex("[^0-9A-Fa-f]"), "")
        if (clean.isEmpty() || clean.length % 2 != 0) return null
        return ByteArray(clean.length / 2) { clean.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    fun hex(b: ByteArray) = b.joinToString(" ") { "%02X".format(it) }

    fun describe(b: ByteArray): String {
        if (b.size < 5 || b[0] != H || b[1] != H) return ""
        val cmd = b[2].toInt() and 0xFF
        val data = b.copyOfRange(minOf(5, b.size), b.size)
        val first = if (data.isNotEmpty()) data[0].toInt() and 0xFF else -1
        return when (cmd) {
            CMD_BATTERY -> if (first >= 0) "Battery: $first%" else "Battery reply"
            CMD_GET_VOLUME, CMD_SET_VOLUME -> if (first >= 0) "Volume: $first" else "Volume reply"
            CMD_DEVICE_STATE -> "Device state: ${hex(data)}"
            CMD_MTU -> "MTU reply: ${hex(data)}"
            CMD_BADGE -> "Badge reply: ${hex(data)}"
            CMD_TEXT -> "Text ack: ${hex(data)}"
            else -> "cmd 0x%02X: %s".format(cmd, hex(data))
        }
    }
}
