package com.ayman.badgepro

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private fun studioMatrix(src: Bitmap, viewPx: Float, zoom: Float, pan: Offset, rot: Float): Matrix {
    val base = maxOf(viewPx / src.width, viewPx / src.height)
    return Matrix().apply {
        postTranslate(-src.width / 2f, -src.height / 2f)
        postScale(base * zoom, base * zoom)
        postRotate(rot)
        postTranslate(viewPx / 2f + pan.x, viewPx / 2f + pan.y)
    }
}

/** Renders exactly what the round preview shows, at the badge's resolution. */
fun renderStudio(src: Bitmap, viewPx: Float, zoom: Float, pan: Offset, rot: Float, outSize: Int): Bitmap {
    val m = studioMatrix(src, viewPx, zoom, pan, rot)
    val k = outSize / viewPx
    m.postScale(k, k)
    val out = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(out)
    c.drawColor(android.graphics.Color.BLACK)
    c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    return out
}

@Composable
fun StudioDialog(src: Bitmap, outSize: Int, onSend: (Bitmap) -> Unit, onClose: () -> Unit) {
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var rot by remember { mutableFloatStateOf(0f) }
    var viewPx by remember { mutableFloatStateOf(1f) }
    val paint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(
                Modifier.fillMaxSize().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("استوديو الصورة", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White)
                Spacer(Modifier.height(6.dp))
                Hint("حرّك بإصبع، كبّر وصغّر بإصبعين، ولفّ بإصبعين كمان. الدائرة هي شكل البادج بالضبط.")
                Spacer(Modifier.height(20.dp))

                Box(
                    Modifier.size(300.dp).border(3.dp, Purple, CircleShape).padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        Modifier.fillMaxSize()
                            .clip(CircleShape)
                            .background(Color.Black)
                            .onSizeChanged { viewPx = it.width.toFloat() }
                            .pointerInput(Unit) {
                                detectTransformGestures { _, p, z, r ->
                                    zoom = (zoom * z).coerceIn(0.3f, 8f)
                                    pan += p
                                    rot += r
                                }
                            }
                    ) {
                        drawContext.canvas.nativeCanvas.drawBitmap(src, studioMatrix(src, size.width, zoom, pan, rot), paint)
                    }
                }

                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Act("↻ 90°") { rot += 90f }
                    Act("➕") { zoom = (zoom * 1.15f).coerceAtMost(8f) }
                    Act("➖") { zoom = (zoom / 1.15f).coerceAtLeast(0.3f) }
                    Act("إعادة") { zoom = 1f; pan = Offset.Zero; rot = 0f }
                }
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onClose, modifier = Modifier.weight(1f).height(52.dp)) { Text("إلغاء") }
                    Button(
                        onClick = { onSend(renderStudio(src, viewPx, zoom, pan, rot, outSize)) },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("ابعتها للبادج ✨", fontSize = 15.sp) }
                }
            }
        }
    }
}
