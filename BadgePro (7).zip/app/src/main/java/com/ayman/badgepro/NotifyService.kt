package com.ayman.badgepro

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Forwards selected phone notifications to the badge as image cards. */
class NotifyService : NotificationListenerService() {

    private val lastShown = HashMap<String, Long>()

    override fun onListenerConnected() {
        Badge.init(applicationContext)
        Badge.log("Notification access active")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        Badge.init(applicationContext)
        val cfg = NotifySettings(applicationContext)
        if (!cfg.enabled) return
        val group = NotifyGroups.groupOf(sbn.packageName) ?: return
        if (group !in cfg.groups) return

        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val isCall = n.category == Notification.CATEGORY_CALL || group == NotifyGroups.CALLS
        if (sbn.isOngoing && !isCall) return
        if (isCall && group != NotifyGroups.CALLS) return // e.g. WhatsApp call ongoing UI

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()
        if (title.isNullOrEmpty()) return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()

        // Don't repeat the same sender too often
        val key = "$group|$title"
        val now = System.currentTimeMillis()
        if (now - (lastShown[key] ?: 0L) < 15_000) return
        lastShown[key] = now

        Badge.log("Notification from $group: $title")
        Badge.screen.showNotification(group, title, if (cfg.hideText || isCall) null else text, cfg.seconds)
    }
}

class NotifySettings(ctx: Context) {
    private val p = ctx.getSharedPreferences("badge", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = p.getBoolean("n_enabled", false)
        set(v) { p.edit().putBoolean("n_enabled", v).apply() }

    var groups: Set<String>
        get() = p.getStringSet("n_groups", setOf(NotifyGroups.WHATSAPP, NotifyGroups.CALLS)) ?: emptySet()
        set(v) { p.edit().putStringSet("n_groups", HashSet(v)).apply() }

    var hideText: Boolean
        get() = p.getBoolean("n_hide", true)
        set(v) { p.edit().putBoolean("n_hide", v).apply() }

    var seconds: Int
        get() = p.getInt("n_secs", 15)
        set(v) { p.edit().putInt("n_secs", v).apply() }
}
