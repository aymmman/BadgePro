package com.ayman.badgepro

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils

/** Draws a round notification card sized for the badge screen. */
object CardRenderer {

    data class Style(val label: String, val emoji: String, val top: Int, val bottom: Int)

    fun styleFor(group: String): Style = when (group) {
        NotifyGroups.WHATSAPP -> Style("WhatsApp", "💬", 0xFF25D366.toInt(), 0xFF075E54.toInt())
        NotifyGroups.CALLS -> Style("مكالمة", "📞", 0xFF2E7DFF.toInt(), 0xFF0B2A6B.toInt())
        NotifyGroups.TELEGRAM -> Style("Telegram", "✈️", 0xFF37AEE2.toInt(), 0xFF1E6A99.toInt())
        NotifyGroups.SMS -> Style("رسالة", "✉️", 0xFFFF9800.toInt(), 0xFF8A3B00.toInt())
        NotifyGroups.INSTAGRAM -> Style("Instagram", "📸", 0xFFE1306C.toInt(), 0xFF5B1A8C.toInt())
        NotifyGroups.MESSENGER -> Style("Messenger", "💭", 0xFF8E5CFF.toInt(), 0xFF2B57D6.toInt())
        else -> Style("إشعار", "🔔", 0xFF7C5CFF.toInt(), 0xFF1A1B33.toInt())
    }

    fun render(size: Int, group: String, title: String, text: String?): Bitmap {
        val st = styleFor(group)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size / 360f

        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.shader = LinearGradient(0f, 0f, 0f, size.toFloat(), st.top, st.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bg)

        // App label at the top
        val label = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(220, 255, 255, 255); textSize = 22f * s; textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        c.drawText("${st.emoji}  ${st.label}", size / 2f, 62f * s, label)

        // Avatar circle with first letter
        val cx = size / 2f
        val cy = 125f * s
        val r = 42f * s
        c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 255, 255, 255) })
        val initial = title.trim().firstOrNull()?.toString() ?: "?"
        val ip = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 46f * s; textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        c.drawText(initial, cx, cy - (ip.descent() + ip.ascent()) / 2, ip)

        // Sender
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 30f * s; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val boxW = (240f * s).toInt()
        val titleText = TextUtils.ellipsize(title, tp, boxW.toFloat(), TextUtils.TruncateAt.END).toString()
        drawCentered(c, titleText, tp, boxW, cx, 190f * s, 1)

        // Message
        if (!text.isNullOrBlank()) {
            val mp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(235, 255, 255, 255); textSize = 22f * s }
            drawCentered(c, text.replace('\n', ' '), mp, (250f * s).toInt(), cx, 236f * s, 3)
        }
        return bmp
    }

    private fun drawCentered(c: Canvas, text: String, paint: TextPaint, width: Int, cx: Float, top: Float, maxLines: Int) {
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setIncludePad(false)
            .build()
        c.save()
        c.translate(cx - width / 2f, top)
        layout.draw(c)
        c.restore()
    }
}

object NotifyGroups {
    const val WHATSAPP = "whatsapp"
    const val CALLS = "calls"
    const val TELEGRAM = "telegram"
    const val SMS = "sms"
    const val INSTAGRAM = "instagram"
    const val MESSENGER = "messenger"

    val packages: Map<String, Set<String>> = mapOf(
        WHATSAPP to setOf("com.whatsapp", "com.whatsapp.w4b"),
        CALLS to setOf(
            "com.samsung.android.incallui", "com.google.android.dialer", "com.android.incallui",
            "com.samsung.android.dialer", "com.android.dialer"
        ),
        TELEGRAM to setOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram"),
        SMS to setOf("com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms"),
        INSTAGRAM to setOf("com.instagram.android"),
        MESSENGER to setOf("com.facebook.orca")
    )

    val labels = linkedMapOf(
        WHATSAPP to "واتساب", CALLS to "المكالمات", TELEGRAM to "تيليجرام",
        SMS to "الرسائل SMS", INSTAGRAM to "إنستغرام", MESSENGER to "ماسنجر"
    )

    fun groupOf(pkg: String): String? = packages.entries.firstOrNull { pkg in it.value }?.key
}
