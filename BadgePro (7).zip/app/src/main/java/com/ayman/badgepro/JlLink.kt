package com.ayman.badgepro

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jieli.bluetooth.bean.BluetoothOption
import com.jieli.bluetooth.bean.base.BaseError
import com.jieli.bluetooth.bean.base.CommandBase
import com.jieli.bluetooth.bean.command.custom.CustomCmd
import com.jieli.bluetooth.bean.device.status.BatteryInfo
import com.jieli.bluetooth.impl.rcsp.RCSPController
import com.jieli.bluetooth.interfaces.bluetooth.RcspCommandCallback
import com.jieli.bluetooth.interfaces.rcsp.callback.BTRcspEventCallback
import com.jieli.bluetooth.utils.CommandBuilder

/**
 * Connection through JieLi's official RCSP SDK (service AE00).
 * On JieLi badges every visible command (emotes, themes, carousel, AI states,
 * recording) goes through this channel as a "custom command" (id 255).
 */
@SuppressLint("MissingPermission")
class JlLink(context: Context, private val log: (String) -> Unit) {

    private val main = Handler(Looper.getMainLooper())

    var connected by mutableStateOf(false)
        private set
    var connecting by mutableStateOf(false)
        private set
    var battery by mutableStateOf(-1)
        private set

    /** Called on the main thread once the RCSP link (including auth) is ready. */
    var onReady: ((BluetoothDevice) -> Unit)? = null
    var onLost: (() -> Unit)? = null

    private val callback = object : BTRcspEventCallback() {
        override fun onConnection(device: BluetoothDevice?, status: Int) {
            log("JL connection status = $status (${statusName(status)})")
            main.post {
                when (status) {
                    1 -> { // CONNECTION_OK
                        connecting = false; connected = true
                        if (device != null) onReady?.invoke(device)
                    }
                    3 -> connecting = true
                    0, 2 -> {
                        val wasConnected = connected
                        connecting = false; connected = false
                        if (wasConnected || status == 2) onLost?.invoke()
                    }
                }
            }
        }

        override fun onDeviceCommand(device: BluetoothDevice?, cmd: CommandBase<*, *>?) {
            if (cmd == null) return
            if (cmd.id == 255) {
                val data = (cmd as? CustomCmd)?.param?.data
                log("JL ← device: ${if (data != null) Protocol.hex(data) else "(empty)"}")
            } else {
                log("JL ← device cmd id ${cmd.id}")
            }
        }

        override fun onBatteryChange(device: BluetoothDevice?, info: BatteryInfo?) {
            if (info != null) {
                log("JL battery = ${info.battery}%")
                main.post { battery = info.battery }
            }
        }
    }

    private val rc: RCSPController

    init {
        if (!RCSPController.isInit()) {
            // Same options as the original app
            RCSPController.init(
                context.applicationContext,
                BluetoothOption.createDefaultOption()
                    .setUseMultiDevice(true)
                    .setPriority(0)
                    .setMandatoryUseBLE(false)
                    .setMtu(509)
                    .setUseDeviceAuth(true)
                    .setBleScanMode(2)
            )
        }
        rc = RCSPController.getInstance()
        rc.addBTRcspEventCallback(callback)
    }

    fun connect(device: BluetoothDevice) {
        log("JL connecting to ${device.address} ...")
        connecting = true
        if (rc.isDeviceConnected(device)) {
            connecting = false; connected = true
            onReady?.invoke(device)
        } else {
            rc.connectDevice(device)
        }
    }

    fun disconnect() {
        val d = rc.usingDevice
        if (d != null) rc.disconnectDevice(d)
        connected = false
        connecting = false
    }

    /** Send a JieLi custom command (the FF F7 ... frames from the original app). */
    fun send(bytes: ByteArray, label: String = "", needReply: Boolean = true) {
        val device = rc.usingDevice
        if (device == null || !connected) {
            log("JL not connected, can't send $label"); return
        }
        log("JL → ${if (label.isNotEmpty()) "$label  " else ""}${Protocol.hex(bytes)}")
        val cmd = if (needReply) CommandBuilder.buildCustomCmd(bytes)
        else CommandBuilder.buildCustomCmdWithoutResponse(bytes)
        rc.sendRcspCommand(device, cmd, object : RcspCommandCallback {
            override fun onCommandResponse(d: BluetoothDevice?, c: CommandBase<*, *>?) {
                if (c == null) { log("JL ✓ (no response object)"); return }
                val data = (c as? CustomCmd)?.response?.data
                log("JL ✓ status=${c.status}" + if (data != null && data.isNotEmpty()) "  data=${Protocol.hex(data)}" else "")
            }

            override fun onErrCode(d: BluetoothDevice?, e: BaseError?) {
                log("JL ✗ error code=${e?.code} sub=${e?.subCode} ${e?.message ?: ""}")
            }
        })
    }

    private fun statusName(s: Int) = when (s) {
        0 -> "disconnected"; 1 -> "connected OK"; 2 -> "failed"; 3 -> "connecting"; 4 -> "already connected"
        else -> "?"
    }
}

/** JieLi custom commands, copied from the original app (DefaultCommandStrategy). */
object JlCmd {
    private fun f(vararg b: Int) = ByteArray(b.size) { b[it].toByte() }

    // Emotes: FF F7 FA [cycle] [type]  type 0=happy 1=angry 2=sad
    fun emote(type: Int, cycle: Int = 1) = f(0xFF, 0xF7, 0xFA, cycle, type)

    // Recording / AI states: FF F7 F1 [x]
    val startTranslate = f(0xFF, 0xF7, 0xF1, 0x00)
    val stopTranslate = f(0xFF, 0xF7, 0xF1, 0x01)
    val aiListening = f(0xFF, 0xF7, 0xF1, 0x02)
    val aiExit = f(0xFF, 0xF7, 0xF1, 0x03)
    val aiThinking = f(0xFF, 0xF7, 0xF1, 0x04)
    val startMeeting = f(0xFF, 0xF7, 0xF1, 0x10)
    val stopMeeting = f(0xFF, 0xF7, 0xF1, 0x11)
    val startRecorder = f(0xFF, 0xF7, 0xF1, 0x12)
    val stopRecorder = f(0xFF, 0xF7, 0xF1, 0x13)
    val interruptReply = f(0xFF, 0xF7, 0xF5, 0x00)

    // Carousel: FF F7 F2 [0=read 1=off 2=ordered 3=shuffle]
    val carouselRead = f(0xFF, 0xF7, 0xF2, 0x00)
    val carouselOff = f(0xFF, 0xF7, 0xF2, 0x01)
    val carouselOrdered = f(0xFF, 0xF7, 0xF2, 0x02)
    val carouselShuffle = f(0xFF, 0xF7, 0xF2, 0x03)

    // Screen off: FF F7 F3 [hi] [lo] seconds, FF FF = never, 00 00 = read
    fun screenOff(seconds: Int) = f(0xFF, 0xF7, 0xF3, (seconds shr 8) and 0xFF, seconds and 0xFF)
    val screenOffNever = f(0xFF, 0xF7, 0xF3, 0xFF, 0xFF)
    val screenOffRead = f(0xFF, 0xF7, 0xF3, 0x00, 0x00)

    // Themes: FF F7 F4 ...
    val themeReset = f(0xFF, 0xF7, 0xF4, 0x00)
    val themeRead = f(0xFF, 0xF7, 0xF4, 0x00, 0x00)
    val themeDefault = f(0xFF, 0xF7, 0xF4, 0x01, 0x03, 0x00)
    val themeSecond = f(0xFF, 0xF7, 0xF4, 0x01, 0x03, 0x01)

    // Audio playback source: FF F7 F8 [1=badge 2=phone]
    val audioToBadge = f(0xFF, 0xF7, 0xF8, 0x01)
    val audioToPhone = f(0xFF, 0xF7, 0xF8, 0x02)

    val languageRead = f(0xFF, 0xF7, 0xF6, 0x00)
}
