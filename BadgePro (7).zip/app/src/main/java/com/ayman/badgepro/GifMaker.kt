package com.ayman.badgepro

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Movie
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File

/** Builds a small looping GIF sized for the badge screen. */
object GifMaker {

    const val FPS = 8
    private const val FRAME_MS = 1000 / FPS

    /** Frames from an animated GIF, center-cropped to size x size. */
    @Suppress("DEPRECATION")
    fun framesFromGif(ctx: Context, uri: Uri, size: Int, maxSeconds: Int): List<Bitmap> {
        val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val movie = Movie.decodeByteArray(bytes, 0, bytes.size)
            ?: throw IllegalStateException("ملف GIF غير صالح")
        val w = movie.width().coerceAtLeast(1)
        val h = movie.height().coerceAtLeast(1)
        val duration = movie.duration().let { if (it <= 0) 1000 else it }
        val total = minOf(duration, maxSeconds * 1000)
        val frames = mutableListOf<Bitmap>()
        val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(raw)
        var t = 0
        while (t < total) {
            raw.eraseColor(Color.BLACK)
            movie.setTime(t)
            movie.draw(c, 0f, 0f)
            frames += cropFill(raw, size)
            t += FRAME_MS
        }
        raw.recycle()
        return frames
    }

    /** Frames from a video, starting at startMs, center-cropped to size x size. */
    fun framesFromVideo(ctx: Context, uri: Uri, size: Int, startMs: Long, seconds: Int): List<Bitmap> {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val frames = mutableListOf<Bitmap>()
            val count = seconds * FPS
            for (i in 0 until count) {
                val t = startMs + i * FRAME_MS.toLong()
                if (dur > 0 && t > dur) break
                val f = r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST) ?: continue
                frames += cropFill(f, size)
                f.recycle()
            }
            if (frames.isEmpty()) throw IllegalStateException("ما قدرت أقرأ الفيديو")
            return frames
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    fun videoDurationMs(ctx: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) { 0L } finally { try { r.release() } catch (_: Exception) {} }
    }

    fun cropFill(src: Bitmap, size: Int): Bitmap {
        val scale = maxOf(size.toFloat() / src.width, size.toFloat() / src.height)
        val cw = (size / scale).toInt().coerceIn(1, src.width)
        val ch = (size / scale).toInt().coerceIn(1, src.height)
        val left = (src.width - cw) / 2
        val top = (src.height - ch) / 2
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, Rect(left, top, left + cw, top + ch), Rect(0, 0, size, size), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** Encode frames to a looping GIF89a with one shared 256-colour palette. */
    fun encode(frames: List<Bitmap>, out: File) {
        require(frames.isNotEmpty())
        val w = frames[0].width
        val h = frames[0].height
        val px = frames.map { f -> IntArray(w * h).also { f.getPixels(it, 0, w, 0, 0, w, h) } }
        out.writeBytes(GifEncoder.encode(w, h, px, FRAME_MS / 10))
    }

}

/** Pure-Kotlin GIF89a encoder (no Android dependencies). */
object GifEncoder {
    fun encode(w: Int, h: Int, frames: List<IntArray>, delayCs: Int): ByteArray {
        // 1) Palette: most common 15-bit colours across all frames
        val hist = IntArray(32768)
        for (pixels in frames) {
            var i = 0
            while (i < pixels.size) { hist[key15(pixels[i])]++; i += 2 }
        }
        val top = hist.indices.filter { hist[it] > 0 }.sortedByDescending { hist[it] }.take(256)
        val used = maxOf(top.size, 1)
        val palette = IntArray(256) { idx ->
            if (idx < top.size) {
                val k = top[idx]
                ((((k shr 10) and 31) * 255 / 31) shl 16) or ((((k shr 5) and 31) * 255 / 31) shl 8) or ((k and 31) * 255 / 31)
            } else 0
        }
        // 2) Lookup table 15-bit colour -> nearest palette index (only for colours that appear)
        val lut = ByteArray(32768)
        val lutDone = BooleanArray(32768)
        fun index(k: Int): Byte {
            if (lutDone[k]) return lut[k]
            val r = ((k shr 10) and 31) * 255 / 31
            val g = ((k shr 5) and 31) * 255 / 31
            val b = (k and 31) * 255 / 31
            var best = 0; var bestD = Int.MAX_VALUE
            for (p in 0 until used) {
                val c = palette[p]
                val dr = r - ((c shr 16) and 255); val dg = g - ((c shr 8) and 255); val db = b - (c and 255)
                val d = dr * dr * 2 + dg * dg * 4 + db * db * 3
                if (d < bestD) { bestD = d; best = p; if (d == 0) break }
            }
            lut[k] = best.toByte(); lutDone[k] = true
            return lut[k]
        }

        val bos = ByteArrayOutputStream()
        bos.write("GIF89a".toByteArray())
        le16(bos, w); le16(bos, h)
        bos.write(0xF7); bos.write(0); bos.write(0)
        for (c in palette) { bos.write((c shr 16) and 255); bos.write((c shr 8) and 255); bos.write(c and 255) }
        bos.write(byteArrayOf(0x21, 0xFF.toByte(), 0x0B))
        bos.write("NETSCAPE2.0".toByteArray())
        bos.write(byteArrayOf(0x03, 0x01, 0x00, 0x00, 0x00))

        val indexed = ByteArray(w * h)
        for (pixels in frames) {
            for (i in pixels.indices) indexed[i] = index(key15(pixels[i]))
            bos.write(byteArrayOf(0x21, 0xF9.toByte(), 0x04, 0x00))
            le16(bos, delayCs)
            bos.write(0); bos.write(0)
            bos.write(0x2C); le16(bos, 0); le16(bos, 0); le16(bos, w); le16(bos, h); bos.write(0)
            bos.write(8)
            writeSubBlocks(bos, lzw(indexed))
        }
        bos.write(0x3B)
        return bos.toByteArray()
    }

    private fun key15(c: Int) = (((c shr 19) and 31) shl 10) or (((c shr 11) and 31) shl 5) or ((c shr 3) and 31)

    private fun le16(o: ByteArrayOutputStream, v: Int) { o.write(v and 255); o.write((v shr 8) and 255) }

    private fun writeSubBlocks(o: ByteArrayOutputStream, data: ByteArray) {
        var i = 0
        while (i < data.size) {
            val n = minOf(255, data.size - i)
            o.write(n); o.write(data, i, n); i += n
        }
        o.write(0)
    }

    /** Standard GIF LZW (min code size 8, variable code length up to 12 bits). */
    private fun lzw(p: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        var bitBuf = 0L
        var bitCount = 0
        fun write(code: Int, size: Int) {
            bitBuf = bitBuf or (code.toLong() shl bitCount)
            bitCount += size
            while (bitCount >= 8) { out.write((bitBuf and 0xFF).toInt()); bitBuf = bitBuf shr 8; bitCount -= 8 }
        }
        val clear = 256
        val eoi = 257
        var cs = 9
        var next = 258
        val dict = HashMap<Int, Int>(8192)
        write(clear, cs)
        if (p.isEmpty()) { write(eoi, cs); if (bitCount > 0) out.write((bitBuf and 0xFF).toInt()); return out.toByteArray() }
        var prefix = p[0].toInt() and 0xFF
        for (i in 1 until p.size) {
            val k = p[i].toInt() and 0xFF
            val key = (prefix shl 8) or k
            val found = dict[key]
            if (found != null) { prefix = found; continue }
            write(prefix, cs)
            if (next >= (1 shl cs) && cs < 12) cs++
            if (next < 4096) {
                dict[key] = next++
            } else {
                write(clear, cs)
                dict.clear(); next = 258; cs = 9
            }
            prefix = k
        }
        write(prefix, cs)
        if (next >= (1 shl cs) && cs < 12) cs++
        write(eoi, cs)
        if (bitCount > 0) out.write((bitBuf and 0xFF).toInt())
        return out.toByteArray()
    }
}
