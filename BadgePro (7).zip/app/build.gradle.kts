plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ayman.badgepro"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ayman.badgepro"
        minSdk = 26
        targetSdk = 34
        versionCode = 12
        versionName = "1.2.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(bom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    // JieLi official RCSP SDK (Apache 2.0, github.com/Jieli-Tech/Android-JL_Bluetooth)
    implementation(files("libs/jl_rcsp.aar", "libs/jl_decryption.aar", "libs/jl_bmp.aar", "libs/jl_gif.aar", "libs/jl_audio.aar"))
    implementation("com.google.code.gson:gson:2.10.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.annotation:annotation:1.8.0")
    implementation("androidx.collection:collection:1.4.0")
}
