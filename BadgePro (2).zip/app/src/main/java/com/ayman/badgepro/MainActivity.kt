package com.ayman.badgepro

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.content.ContextCompat

private val Purple = Color(0xFF7C5CFF)
private val Bg = Color(0xFF0F1020)
private val CardBg = Color(0xFF1A1B33)

class MainActivity : ComponentActivity() {
    private lateinit var ble: BadgeBle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ble = BadgeBle(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple, background = Bg, surface = CardBg,
                    onPrimary = Color.White, onSurface = Color.White, onBackground = Color.White
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App(ble) }
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) ble.disconnect()
        super.onDestroy()
    }
}

private fun neededPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

private fun hasPermissions(ctx: Context) = neededPermissions().all {
    ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
}

@Composable
fun App(ble: BadgeBle) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasPermissions(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted = hasPermissions(ctx) }
    val enableBt = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    fun startScanFlow() {
        if (!granted) { permLauncher.launch(neededPermissions()); return }
        if (!ble.isBluetoothOn) {
            try { enableBt.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) {}
            return
        }
        ble.startScan()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header(ble) }

        if (ble.state != LinkState.CONNECTED) {
            item {
                Button(
                    onClick = { startScanFlow() },
                    enabled = ble.state != LinkState.CONNECTING,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        when (ble.state) {
                            LinkState.SCANNING -> "جاري البحث..."
                            LinkState.CONNECTING -> "جاري الاتصال..."
                            else -> "ابحث عن البادج"
                        }, fontSize = 16.sp
                    )
                }
                if (!granted) Text(
                    "التطبيق بحاجة لصلاحية البلوتوث. اضغط الزر واسمح بها.",
                    color = Color(0xFFFFC107), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                )
                Text(
                    "تأكد إن تطبيق BagiBagi مسكّر تمامًا قبل الاتصال.",
                    color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            items(ble.devices, key = { it.address }) { d ->
                DeviceRow(d) { ble.connect(d) }
            }
        } else {
            item { ConnectedPanel(ble) }
        }

        item { LogPanel(ble) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Header(ble: BadgeBle) {
    Row(
        Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(Modifier.size(44.dp), shape = CircleShape, color = Purple) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("B", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("BadgePro", fontWeight = FontWeight.Bold, fontSize = 22.sp)
            val (label, color) = when (ble.state) {
                LinkState.CONNECTED -> "متصل بـ ${ble.connectedName}" to Color(0xFF4CAF50)
                LinkState.CONNECTING -> "جاري الاتصال..." to Color(0xFFFFC107)
                LinkState.SCANNING -> "جاري البحث..." to Color(0xFFFFC107)
                LinkState.IDLE -> "غير متصل" to Color.Gray
            }
            Text(label, color = color, fontSize = 13.sp)
        }
        if (ble.state == LinkState.SCANNING || ble.state == LinkState.CONNECTING) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
        }
    }
}

@Composable
fun DeviceRow(d: FoundDevice, onClick: () -> Unit) {
    val isBadge = d.name.startsWith("Z0")
    Card(
        Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (isBadge) Color(0xFF2A2366) else CardBg),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.name + if (isBadge) "  ⭐" else "", fontWeight = FontWeight.SemiBold)
                Text(d.address, color = Color.Gray, fontSize = 12.sp)
            }
            Text("${d.rssi} dBm", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Purple)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

@Composable
fun Act(label: String, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, shape = RoundedCornerShape(12.dp)) { Text(label, fontSize = 13.sp) }
}

@Composable
fun ConnectedPanel(ble: BadgeBle) {
    var text by remember { mutableStateOf("مرحبا من BadgePro") }
    var hex by remember { mutableStateOf("88 88 01 01 00") }
    var newName by remember { mutableStateOf("") }
    var volume by remember { mutableFloatStateOf(8f) }
    var confirmReset by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MTU: ${ble.mtu}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { ble.disconnect() }) { Text("قطع الاتصال") }
        }
        if (ble.lastInfo.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF16351F))) {
                Text("آخر رد: ${ble.lastInfo}", Modifier.padding(12.dp), color = Color(0xFF8BE59B))
            }
        }

        Section("1. معلومات الجهاز") {
            Chips {
                Act("البطارية") { ble.send(Protocol.battery()) }
                Act("حالة الجهاز") { ble.send(Protocol.deviceState()) }
                Act("معلومات الشاشة") { ble.send(Protocol.wallpaperInfo()) }
                Act("MTU") { ble.send(Protocol.mtu()) }
                Act("قراءة الصوت") { ble.send(Protocol.getVolume()) }
            }
        }

        Section("2. نص على الشاشة (أهم تجربة)") {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(), label = { Text("اكتب نص") }
            )
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("ابعث النص") { if (text.isNotBlank()) ble.sendText(text) }
                Act("تجربة إنجليزي") { ble.sendText("Hello from BadgePro") }
                Act("تجربة إشعار") { ble.sendText("واتساب: أحمد - وين صرت؟") }
            }
        }

        Section("3. عرض الصور والشاشة") {
            Text("تبديل الصور:", color = Color.Gray, fontSize = 13.sp)
            Chips {
                Act("افتراضي") { ble.send(Protocol.carouselDefault()) }
                Act("بالترتيب") { ble.send(Protocol.carouselOrdered()) }
                Act("عشوائي") { ble.send(Protocol.carouselShuffle()) }
                Act("اقرأ الوضع") { ble.send(Protocol.readCarousel()) }
            }
            Spacer(Modifier.height(8.dp))
            Text("إطفاء الشاشة تلقائيًا:", color = Color.Gray, fontSize = 13.sp)
            Chips {
                Act("5") { ble.send(Protocol.screenOff(0x0A)) }
                Act("10") { ble.send(Protocol.screenOff(0x0B)) }
                Act("15") { ble.send(Protocol.screenOff(0x0C)) }
            }
            Spacer(Modifier.height(8.dp))
            Chips { Act("رجّع الثيم الأصلي") { ble.send(Protocol.restoreTheme()) } }
        }

        Section("4. الصوت والتسجيل") {
            Text("مستوى الصوت: ${volume.toInt()}", color = Color.Gray, fontSize = 13.sp)
            Slider(value = volume, onValueChange = { volume = it }, valueRange = 0f..16f, steps = 15,
                onValueChangeFinished = { ble.send(Protocol.setVolume(volume.toInt())) })
            Chips {
                Act("ابدأ تسجيل") { ble.send(Protocol.startRecord()) }
                Act("وقّف تسجيل") { ble.send(Protocol.stopRecord()) }
                Act("دوّر على جهازي") { ble.send(Protocol.searchDevice(true)) }
                Act("وقّف البحث") { ble.send(Protocol.searchDevice(false)) }
            }
        }

        Section("5. اسم الجهاز") {
            OutlinedTextField(
                value = newName, onValueChange = { newName = it.take(20) },
                modifier = Modifier.fillMaxWidth(), label = { Text("اسم جديد (إنجليزي أفضل)") }
            )
            Spacer(Modifier.height(8.dp))
            Chips { Act("غيّر الاسم") { if (newName.isNotBlank()) ble.send(Protocol.rename(newName.trim())) } }
        }

        Section("6. مختبر الأوامر (Hex)") {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                OutlinedTextField(
                    value = hex, onValueChange = { hex = it },
                    modifier = Modifier.fillMaxWidth(), label = { Text("Hex bytes") },
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
                )
            }
            Spacer(Modifier.height(8.dp))
            Chips {
                Act("ابعث") {
                    val b = Protocol.parseHex(hex)
                    if (b == null) ble.addLog("Hex غير صحيح") else ble.send(b)
                }
            }
        }

        Section("⚠️ منطقة خطرة") {
            Text("إعادة ضبط المصنع بتمسح الصور والإعدادات من البادج.", color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { confirmReset = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))
            ) { Text("إعادة ضبط المصنع") }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("متأكد؟") },
            text = { Text("رح تنمسح كل الصور والإعدادات من البادج.") },
            confirmButton = {
                TextButton(onClick = { confirmReset = false; ble.send(Protocol.resetFactory()) }) { Text("نعم، امسح") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun LogPanel(ble: BadgeBle) {
    val ctx = LocalContext.current
    Section("سجل الاتصال") {
        Row {
            Act("انسخ السجل") {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("BadgePro log", ble.logText()))
                Toast.makeText(ctx, "تم النسخ، الصقه لـ Claude", Toast.LENGTH_SHORT).show()
            }
            Spacer(Modifier.width(8.dp))
            Act("امسح") { ble.log.clear() }
        }
        Spacer(Modifier.height(8.dp))
        if (ble.services.isNotEmpty()) {
            Text("Services:", color = Color.Gray, fontSize = 12.sp)
            ble.services.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFB0B3FF)) }
            Spacer(Modifier.height(8.dp))
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(
                Modifier.fillMaxWidth().background(Color(0xFF0A0A16), RoundedCornerShape(10.dp)).padding(8.dp)
            ) {
                if (ble.log.isEmpty()) Text("No activity yet", color = Color.Gray, fontSize = 12.sp)
                ble.log.take(80).forEach { line ->
                    val c = when {
                        "RX" in line -> Color(0xFF8BE59B)
                        "TX" in line -> Color(0xFF9FB4FF)
                        else -> Color(0xFFCCCCCC)
                    }
                    Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = c)
                }
            }
        }
    }
}
