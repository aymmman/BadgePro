package com.ayman.badgepro

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Voice assistant using the OpenAI API:
 * badge mic (PCM) → speech-to-text → ChatGPT → text-to-speech → badge speaker.
 */
class AiAssistant(context: Context, private val voice: VoiceLink, private val log: (String) -> Unit) {

    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val prefs: SharedPreferences = securePrefs(ctx)
    private val history = ArrayDeque<JSONObject>()

    var busy by mutableStateOf(false); private set
    var lastQuestion by mutableStateOf(""); private set
    var lastAnswer by mutableStateOf(""); private set
    var lastTiming by mutableStateOf(""); private set

    var apiKey: String
        get() = prefs.getString("openai_key", "") ?: ""
        set(v) { prefs.edit().putString("openai_key", v.trim()).apply() }
    var enabled: Boolean
        get() = prefs.getBoolean("ai_enabled", true)
        set(v) { prefs.edit().putBoolean("ai_enabled", v).apply() }
    var openAiVoice: Boolean
        get() = prefs.getBoolean("ai_openai_voice", true)
        set(v) { prefs.edit().putBoolean("ai_openai_voice", v).apply() }
    var voiceName: String
        get() = prefs.getString("ai_voice", "nova") ?: "nova"
        set(v) { prefs.edit().putString("ai_voice", v).apply() }
    var chatModel: String
        get() = prefs.getString("ai_chat_model", "gpt-4o-mini") ?: "gpt-4o-mini"
        set(v) { prefs.edit().putString("ai_chat_model", v.trim()).apply() }
    var sttModel: String
        get() = prefs.getString("ai_stt_model", "gpt-4o-mini-transcribe") ?: "gpt-4o-mini-transcribe"
        set(v) { prefs.edit().putString("ai_stt_model", v.trim()).apply() }
    var ttsModel: String
        get() = prefs.getString("ai_tts_model", "gpt-4o-mini-tts") ?: "gpt-4o-mini-tts"
        set(v) { prefs.edit().putString("ai_tts_model", v.trim()).apply() }
    var persona: String
        get() = prefs.getString("ai_persona", DEFAULT_PERSONA) ?: DEFAULT_PERSONA
        set(v) { prefs.edit().putString("ai_persona", v).apply() }

    val ready: Boolean get() = apiKey.startsWith("sk-")

    /** Entry point from the badge microphone. */
    fun onSpeech(pcm: ByteArray, rate: Int) {
        if (!enabled || !ready) {
            if (!ready) voice.speak("لازم تحط مفتاح OpenAI بالتطبيق أول")
            else voice.screenExit()
            return
        }
        if (pcm.size < rate * 2 / 2) { log("Speech too short"); voice.screenExit(); return }
        run(audio = pcm, rate = rate, typed = null)
    }

    /** Typed question (test without the badge mic). */
    fun ask(text: String) {
        if (!ready) { log("✗ No API key"); return }
        voice.screenThinking()
        run(audio = null, rate = 0, typed = text)
    }

    fun clearMemory() { history.clear(); log("AI memory cleared") }

    private fun run(audio: ByteArray?, rate: Int, typed: String?) {
        if (busy) return
        busy = true
        Thread {
            val t0 = System.currentTimeMillis()
            try {
                val question = typed ?: transcribe(wav(audio!!, rate))
                val t1 = System.currentTimeMillis()
                log("🗣️ You: $question")
                main.post { lastQuestion = question }
                if (question.isBlank()) { voice.screenExit(); return@Thread }

                val answer = chat(question)
                val t2 = System.currentTimeMillis()
                log("🤖 AI: $answer")
                main.post { lastAnswer = answer }

                if (openAiVoice) {
                    val pcm = try { tts(answer) } catch (e: Exception) { log("✗ OpenAI voice: ${e.message}"); null }
                    val t3 = System.currentTimeMillis()
                    main.post { lastTiming = "سماع ${(t1 - t0) / 100 / 10.0}ث • تفكير ${(t2 - t1) / 100 / 10.0}ث • صوت ${(t3 - t2) / 100 / 10.0}ث" }
                    if (pcm != null) voice.playPcm(pcm, 24000) else voice.speak(answer)
                } else {
                    main.post { lastTiming = "سماع ${(t1 - t0) / 100 / 10.0}ث • تفكير ${(t2 - t1) / 100 / 10.0}ث" }
                    voice.speak(answer)
                }
            } catch (e: Exception) {
                log("✗ AI: ${e.message}")
                main.post { lastAnswer = "خطأ: ${e.message}" }
                voice.speak("صار خطأ، جرّب مرة ثانية")
            } finally {
                main.post { busy = false }
            }
        }.start()
    }

    // ---------------- OpenAI calls ----------------

    private fun transcribe(wavBytes: ByteArray): String {
        return try { transcribeWith(sttModel, wavBytes) }
        catch (e: ApiException) {
            if (e.code == 404 || e.code == 400) { log("STT model failed (${e.code}), trying whisper-1"); transcribeWith("whisper-1", wavBytes) }
            else throw e
        }
    }

    private fun transcribeWith(model: String, wavBytes: ByteArray): String {
        val boundary = "----badge" + System.currentTimeMillis()
        val c = open("https://api.openai.com/v1/audio/transcriptions")
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        DataOutputStream(c.outputStream).use { o ->
            fun field(name: String, value: String) {
                o.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n")
                o.write(value.toByteArray()); o.writeBytes("\r\n")
            }
            field("model", model)
            field("response_format", "json")
            o.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
            o.write(wavBytes)
            o.writeBytes("\r\n--$boundary--\r\n")
        }
        return JSONObject(read(c)).optString("text").trim()
    }

    private fun chat(question: String): String {
        history.addLast(JSONObject().put("role", "user").put("content", question))
        while (history.size > 10) history.removeFirst()
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", persona))
        history.forEach { messages.put(it) }
        val body = JSONObject().put("model", chatModel).put("messages", messages).put("max_tokens", 300)
        val c = open("https://api.openai.com/v1/chat/completions")
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val answer = JSONObject(read(c)).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content").trim()
        history.addLast(JSONObject().put("role", "assistant").put("content", answer))
        return answer
    }

    private fun tts(text: String): ByteArray {
        val body = JSONObject().put("model", ttsModel).put("voice", voiceName)
            .put("input", text).put("response_format", "pcm")
        val c = open("https://api.openai.com/v1/audio/speech")
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        if (code !in 200..299) throw ApiException(code, c.errorStream?.bufferedReader()?.readText() ?: "")
        return c.inputStream.use { it.readBytes() }
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true
            connectTimeout = 15000; readTimeout = 60000
            setRequestProperty("Authorization", "Bearer $apiKey")
        }

    private fun read(c: HttpURLConnection): String {
        val code = c.responseCode
        if (code !in 200..299) {
            val err = c.errorStream?.bufferedReader()?.readText() ?: ""
            val msg = try { JSONObject(err).getJSONObject("error").optString("message") } catch (_: Exception) { err.take(200) }
            throw ApiException(code, msg)
        }
        return c.inputStream.bufferedReader().readText()
    }

    class ApiException(val code: Int, msg: String) : Exception("HTTP $code: $msg")

    private fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val o = ByteArrayOutputStream()
        fun i32(v: Int) { o.write(v and 255); o.write((v shr 8) and 255); o.write((v shr 16) and 255); o.write((v shr 24) and 255) }
        fun i16(v: Int) { o.write(v and 255); o.write((v shr 8) and 255) }
        o.write("RIFF".toByteArray()); i32(36 + pcm.size); o.write("WAVE".toByteArray())
        o.write("fmt ".toByteArray()); i32(16); i16(1); i16(1); i32(rate); i32(rate * 2); i16(2); i16(16)
        o.write("data".toByteArray()); i32(pcm.size); o.write(pcm)
        return o.toByteArray()
    }

    companion object {
        const val DEFAULT_PERSONA =
            "أنت مساعد صوتي ذكي اسمه بادج، على جهاز صغير يلبسه أيمن. جاوب باختصار شديد، جملة أو جملتين، " +
            "وبنفس لغة السؤال. إذا السؤال بالعربي جاوب بلهجة أردنية طبيعية وواضحة. " +
            "لا تستخدم رموز أو قوائم أو إيموجي لأنه جوابك رح ينقرأ بصوت."

        val VOICES = listOf("nova", "shimmer", "alloy", "echo", "onyx", "coral", "sage")

        private fun securePrefs(ctx: Context): SharedPreferences = try {
            val alias = androidx.security.crypto.MasterKeys.getOrCreate(androidx.security.crypto.MasterKeys.AES256_GCM_SPEC)
            androidx.security.crypto.EncryptedSharedPreferences.create(
                "ai_secure", alias, ctx,
                androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            ctx.getSharedPreferences("ai_plain", Context.MODE_PRIVATE)
        }
    }
}
