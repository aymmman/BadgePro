package com.ayman.badgepro

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jieli.bluetooth.bean.base.BaseError
import com.jieli.bluetooth.bean.record.RecordParam
import com.jieli.bluetooth.bean.record.RecordState
import com.jieli.bluetooth.impl.rcsp.RCSPController
import com.jieli.bluetooth.impl.rcsp.record.RecordOpImpl
import com.jieli.bluetooth.interfaces.rcsp.callback.OnRcspActionCallback
import com.jieli.bluetooth.interfaces.rcsp.record.OnRecordStateCallback
import com.jieli.jl_audio_decode.callback.OnDecodeStreamCallback
import com.jieli.jl_audio_decode.callback.OnStateCallback
import com.jieli.jl_audio_decode.opus.OpusManager
import com.jieli.jl_audio_decode.opus.model.OpusOption
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.util.Locale

/**
 * Voice features of the badge:
 *  - mic: the badge streams Opus audio through the JieLi record API (double-click the button)
 *  - speaker: the badge is also a classic Bluetooth audio device
 *  - native screens: Listening / Thinking / Speaking animations driven by custom commands
 */
@SuppressLint("MissingPermission")
class VoiceLink(context: Context, private val log: (String) -> Unit) {

    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val rc = RCSPController.getInstance()
    private val recordOp: RecordOpImpl = RecordOpImpl.getInstance(rc.rcspOp)
    private val buffer = ByteArrayOutputStream()
    private var param: RecordParam? = null
    private var tts: TextToSpeech? = null

    // ---- Voice activity detection (auto stop when you stop talking) ----
    private var vadDecoder: OpusManager? = null
    private var vadStart = 0L
    private var noiseFloor = 0.0
    private var noiseFrames = 0
    private var heardSpeech = false
    private var lastLoud = 0L
    private var stopRequested = false
    var vadEnabled = true
    private var ttsReady = false

    var status by mutableStateOf("دبل كليك على زر البادج واحكي جملة"); private set
    var recording by mutableStateOf(false); private set
    var blocks by mutableStateOf(0); private set
    var lastInfo by mutableStateOf(""); private set
    var lastWav by mutableStateOf<File?>(null); private set
    var speakerOk by mutableStateOf(false); private set

    /** Called with the recorded speech as 16 kHz mono PCM (Phase B plugs ChatGPT in here). */
    var onSpeech: ((pcm: ByteArray, sampleRate: Int) -> Unit)? = null

    private val device: BluetoothDevice? get() = rc.usingDevice

    private val callback = object : OnRecordStateCallback {
        override fun onStateChange(d: BluetoothDevice?, s: RecordState?) {
            s ?: return
            when (s.state) {
                RecordState.RECORD_STATE_START -> {
                    param = s.recordParam
                    buffer.reset()
                    log("🎙️ Record START  param=${s.recordParam}")
                    startVad()
                    main.post { recording = true; blocks = 0; status = "🎙️ بسمع... احكي هلأ" }
                }
                RecordState.RECORD_STATE_WORKING -> {
                    s.voiceDataBlock?.let { buffer.write(it); try { vadDecoder?.writeAudioStream(it) } catch (_: Exception) {} }
                    main.post { blocks++ }
                    checkTimeouts()
                }
                RecordState.RECORD_STATE_IDLE -> {
                    val data = s.voiceData?.takeIf { it.isNotEmpty() } ?: buffer.toByteArray()
                    log("⏹ Record STOP reason=${s.reason} ${s.message ?: ""} bytes=${data.size}")
                    stopVad()
                    main.post { recording = false }
                    if (data.isNotEmpty()) handleRecording(data) else main.post { status = "ما وصل صوت (${s.reason})" }
                }
            }
        }
    }

    init {
        recordOp.addOnRecordStateCallback(callback)
        tts = TextToSpeech(ctx) { st ->
            ttsReady = st == TextToSpeech.SUCCESS
            if (ttsReady) {
                val r = tts?.setLanguage(Locale("ar"))
                log("TTS ready, Arabic=${r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED}")
            }
        }
    }

    // ---------------- Native AI screens ----------------
    private fun f(vararg b: Int) = ByteArray(b.size) { b[it].toByte() }
    fun screenThinking() = Badge.jl.send(f(0xFF, 0xF7, 0xF1, 0x04), "AI thinking")
    fun screenSpeaking() = Badge.jl.send(f(0xFF, 0xF7, 0xF1, 0x02), "AI speaking")
    fun screenExit() = Badge.jl.send(f(0xFF, 0xF7, 0xF1, 0x03), "AI exit")

    // ---------------- Recording ----------------

    fun startManual() {
        val d = device ?: return
        val p = RecordParam(RecordParam.VOICE_TYPE_OPUS, RecordParam.SAMPLE_RATE_16K, RecordParam.VAD_WAY_DEVICE)
        recordOp.startRecord(d, p, object : OnRcspActionCallback<Boolean> {
            override fun onSuccess(dev: BluetoothDevice?, ok: Boolean?) { log("✓ Manual record started") }
            override fun onError(dev: BluetoothDevice?, e: BaseError?) { log("✗ Manual record: ${e?.subCode} ${e?.message}") }
        })
    }

    private fun startVad() {
        stopVad()
        vadStart = System.currentTimeMillis()
        noiseFloor = 0.0; noiseFrames = 0; heardSpeech = false; lastLoud = vadStart; stopRequested = false
        if (!vadEnabled) return
        try {
            val om = OpusManager()
            om.startDecodeStream(OpusOption(), object : OnDecodeStreamCallback {
                override fun onStart() {}
                override fun onComplete(p: String?) {}
                override fun onError(code: Int, msg: String?) { log("VAD decoder error $code $msg") }
                override fun onDecodeStream(pcm: ByteArray?) { if (pcm != null) analyse(pcm) }
            })
            vadDecoder = om
        } catch (e: Exception) { log("VAD off: ${e.message}") }
    }

    private fun stopVad() {
        val om = vadDecoder ?: return
        vadDecoder = null
        try { om.stopDecodeStream() } catch (_: Exception) {}
        try { om.release() } catch (_: Exception) {}
    }

    /** Energy-based speech detection on decoded 16-bit PCM. */
    private fun analyse(pcm: ByteArray) {
        var sum = 0.0
        var n = 0
        var i = 0
        while (i + 1 < pcm.size) {
            val v = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toDouble()
            sum += v * v; n++; i += 2
        }
        if (n == 0) return
        val rms = Math.sqrt(sum / n)
        val now = System.currentTimeMillis()
        if (now - vadStart < 400) { // learn background noise first
            noiseFloor = (noiseFloor * noiseFrames + rms) / (noiseFrames + 1); noiseFrames++
            return
        }
        val threshold = maxOf(500.0, noiseFloor * 3.0)
        if (rms > threshold) {
            if (!heardSpeech) log("VAD: speech detected (rms ${rms.toInt()}, floor ${noiseFloor.toInt()})")
            heardSpeech = true; lastLoud = now
        }
        if (heardSpeech && now - lastLoud > SILENCE_MS) requestStop("silence")
    }

    private fun checkTimeouts() {
        val now = System.currentTimeMillis()
        if (!heardSpeech && now - vadStart > NO_SPEECH_MS) requestStop("no speech")
        if (now - vadStart > MAX_MS) requestStop("max length")
    }

    private fun requestStop(why: String) {
        if (stopRequested) return
        stopRequested = true
        log("VAD: auto stop ($why)")
        main.post { stopManual() }
    }

    /** The badge asks to start listening (double-click): FF F7 F1 00. */
    fun onDeviceRequest(data: ByteArray) {
        if (data.size < 4 || data[0] != 0xFF.toByte() || data[1] != 0xF7.toByte() || data[2] != 0xF1.toByte()) return
        when (data[3].toInt() and 0xFF) {
            0x00 -> if (!recordOp.isRecording(device)) { log("Badge asked to listen → starting"); startManual() }
            0x01 -> if (recordOp.isRecording(device)) { log("Badge asked to stop → stopping"); stopManual() }
            0x03 -> log("Badge left AI mode")
        }
    }

    fun stopManual() {
        val d = device ?: return
        recordOp.stopRecord(d, RecordState.REASON_NORMAL, object : OnRcspActionCallback<Boolean> {
            override fun onSuccess(dev: BluetoothDevice?, ok: Boolean?) { log("✓ Manual record stopped") }
            override fun onError(dev: BluetoothDevice?, e: BaseError?) { log("✗ Stop record: ${e?.subCode} ${e?.message}") }
        })
    }

    private fun handleRecording(data: ByteArray) {
        screenThinking()
        val type = param?.voiceType ?: RecordParam.VOICE_TYPE_OPUS
        val rate = if (param?.sampleRate == RecordParam.SAMPLE_RATE_8K) 8000 else 16000
        main.post { status = "🤔 بفك الصوت... (${data.size} بايت)" }
        val dir = File(ctx.cacheDir, "voice").apply { mkdirs() }
        when (type) {
            RecordParam.VOICE_TYPE_PCM -> finish(data, rate, dir)
            RecordParam.VOICE_TYPE_OPUS -> {
                val inFile = File(dir, "last.opus").apply { writeBytes(data) }
                val outFile = File(dir, "last.pcm")
                try {
                    val om = OpusManager()
                    om.decodeFile(inFile.path, outFile.path, OpusOption().setSampleRate(rate), object : OnStateCallback {
                        override fun onStart() {}
                        override fun onComplete(path: String?) {
                            val pcm = File(path ?: outFile.path).readBytes()
                            om.release()
                            finish(pcm, rate, dir)
                        }
                        override fun onError(code: Int, msg: String?) {
                            om.release()
                            log("✗ Opus decode $code $msg")
                            main.post { status = "فشل فك الصوت ($code)"; screenExit() }
                        }
                    })
                } catch (e: Exception) {
                    log("✗ Opus init: ${e.message}")
                    main.post { status = "فشل فك الصوت"; screenExit() }
                }
            }
            else -> {
                log("✗ Unsupported voice type $type (speex)")
                main.post { status = "نوع صوت غير مدعوم ($type)"; screenExit() }
            }
        }
    }

    private fun finish(pcm: ByteArray, rate: Int, dir: File) {
        val secs = pcm.size / 2.0 / rate
        val wav = File(dir, "last.wav")
        writeWav(wav, pcm, rate)
        log("✓ Speech decoded: ${"%.1f".format(secs)} s, ${pcm.size} bytes PCM")
        main.post {
            lastWav = wav
            lastInfo = "آخر تسجيل: ${"%.1f".format(secs)} ثانية"
            status = "✅ وصل صوتك! اضغط تشغيل لتسمعه"
            val handler = onSpeech
            if (handler != null) handler(pcm, rate) else screenExit()
        }
    }

    // ---------------- Playback / speaker ----------------

    fun playLast() {
        val f = lastWav ?: return
        val bytes = f.readBytes()
        if (bytes.size <= 44) return
        val rate = java.nio.ByteBuffer.wrap(bytes, 24, 4).order(java.nio.ByteOrder.LITTLE_ENDIAN).int
        playPcm(bytes.copyOfRange(44, bytes.size), rate)
    }

    fun playPcm(pcm: ByteArray, rate: Int, onDone: (() -> Unit)? = null) {
        Thread {
            try {
                screenSpeaking()
                val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(rate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(maxOf(minBuf, 4096))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track.play()
                var off = 0
                while (off < pcm.size) {
                    val n = minOf(4096, pcm.size - off)
                    track.write(pcm, off, n)
                    off += n
                }
                Thread.sleep(300)
                track.stop(); track.release()
            } catch (e: Exception) {
                log("✗ Playback: ${e.message}")
            } finally {
                screenExit()
                main.post { onDone?.invoke() }
            }
        }.start()
    }

    fun speak(text: String) {
        val t = tts
        if (t == null || !ttsReady) { log("✗ TTS not ready"); return }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { screenSpeaking() }
            override fun onDone(id: String?) { screenExit() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { screenExit() }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "badge")
    }

    fun refreshSpeaker() {
        val d = device ?: run { speakerOk = false; return }
        speakerOk = try { rc.bluetoothManager.isConnectedByProfile(d) } catch (_: Exception) { false }
    }

    fun connectSpeaker() {
        val d = device ?: return
        log("Connecting badge speaker (classic Bluetooth)...")
        try { rc.bluetoothManager.startConnectByBreProfiles(d) } catch (e: Exception) { log("✗ Speaker: ${e.message}") }
        main.postDelayed({ refreshSpeaker() }, 4000)
    }

    private fun writeWav(f: File, pcm: ByteArray, rate: Int) {
        RandomAccessFile(f, "rw").use { r ->
            r.setLength(0)
            fun i32(v: Int) { r.write(byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())) }
            fun i16(v: Int) { r.write(byteArrayOf(v.toByte(), (v shr 8).toByte())) }
            r.write("RIFF".toByteArray()); i32(36 + pcm.size); r.write("WAVE".toByteArray())
            r.write("fmt ".toByteArray()); i32(16); i16(1); i16(1); i32(rate); i32(rate * 2); i16(2); i16(16)
            r.write("data".toByteArray()); i32(pcm.size); r.write(pcm)
        }
    }

    companion object {
        const val SILENCE_MS = 1300L
        const val NO_SPEECH_MS = 7000L
        const val MAX_MS = 25000L
    }
}
